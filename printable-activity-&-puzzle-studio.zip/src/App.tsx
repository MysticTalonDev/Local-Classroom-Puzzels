import React, { useState, useEffect } from 'react';
import { GeneratorType, HeaderSettings } from './types.ts';
import { Navbar, GENERATORS } from './components/Navbar.tsx';
import { HeaderSettingsModal } from './components/HeaderSettingsModal.tsx';
import { PdfPrintModal } from './components/PdfPrintModal.tsx';
import { generatePdfFromWorksheet, PdfGenerationResult } from './utils/pdfExport.ts';
import { WordSearchView } from './components/views/WordSearchView.tsx';
import { CrosswordView } from './components/views/CrosswordView.tsx';
import { BingoView } from './components/views/BingoView.tsx';
import { WordScrambleView } from './components/views/WordScrambleView.tsx';
import { CryptogramView } from './components/views/CryptogramView.tsx';
import { MazeView } from './components/views/MazeView.tsx';
import { MatchingView } from './components/views/MatchingView.tsx';
import { SudokuView } from './components/views/SudokuView.tsx';
import { WordLadderView } from './components/views/WordLadderView.tsx';
import { FillBlankView } from './components/views/FillBlankView.tsx';
import { PRESETS } from './data/presets.ts';

export default function App() {
  const [activeGenerator, setActiveGenerator] = useState<GeneratorType>('word-search');
  const [showAnswerKey, setShowAnswerKey] = useState<boolean>(false);
  const [printSeparateKey, setPrintSeparateKey] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);

  // Dark Mode State
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('puzzle_studio_theme');
      if (saved) return saved === 'dark';
      return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch {
      return false;
    }
  });

  useEffect(() => {
    try {
      if (isDarkMode) {
        document.documentElement.classList.add('dark');
        document.body.classList.add('dark');
        localStorage.setItem('puzzle_studio_theme', 'dark');
      } else {
        document.documentElement.classList.remove('dark');
        document.body.classList.remove('dark');
        localStorage.setItem('puzzle_studio_theme', 'light');
      }
    } catch {
      // Ignore localStorage exceptions in restricted contexts
    }
  }, [isDarkMode]);

  // PDF Generation & Print Modal State
  const [isPdfModalOpen, setIsPdfModalOpen] = useState<boolean>(false);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState<boolean>(false);
  const [pdfProgressText, setPdfProgressText] = useState<string>('');
  const [pdfError, setPdfError] = useState<string | null>(null);
  const [pdfResult, setPdfResult] = useState<PdfGenerationResult | null>(null);

  // Global Header and Styling Settings
  const [headerSettings, setHeaderSettings] = useState<HeaderSettings>({
    title: PRESETS['word-search'][0].title,
    subtitle: PRESETS['word-search'][0].subtitle,
    showNameLine: true,
    showDateLine: true,
    showScoreLine: true,
    showTeacherLine: false,
    fontSize: 'base',
    borderColor: '#0f172a',
    fontFamily: 'sans',
  });

  const handleSelectGenerator = (gen: GeneratorType) => {
    setActiveGenerator(gen);
    setShowAnswerKey(false);
    // Reset any cached PDF result so fresh generator gets fresh export
    setPdfResult(null);
    // Apply first preset metadata of the selected generator
    const defaultPreset = (PRESETS as any)[gen]?.[0];
    if (defaultPreset) {
      setHeaderSettings(prev => ({
        ...prev,
        title: defaultPreset.title || prev.title,
        subtitle: defaultPreset.subtitle || '',
      }));
    }
  };

  const handleOpenPdfPrint = async () => {
    setIsPdfModalOpen(true);
    setIsGeneratingPdf(true);
    setPdfError(null);

    // Give DOM a tick to ensure latest state is settled
    await new Promise(r => setTimeout(r, 60));

    try {
      const result = await generatePdfFromWorksheet(
        headerSettings.title || 'Worksheet',
        text => setPdfProgressText(text)
      );
      setPdfResult(result);
    } catch (err: any) {
      console.error('PDF export error:', err);
      setPdfError(err?.message || 'Failed to render worksheet into PDF.');
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // Intercept Ctrl+P / Cmd+P to open the PDF Print dialog
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'p') {
        e.preventDefault();
        handleOpenPdfPrint();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [headerSettings.title, activeGenerator, showAnswerKey, printSeparateKey]);

  const currentGenMeta = GENERATORS.find(g => g.id === activeGenerator);

  return (
    <div className={`min-h-screen flex flex-col bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors ${isDarkMode ? 'dark' : ''}`}>
      {/* Top Application Navigation & Print Controls */}
      <Navbar
        activeGenerator={activeGenerator}
        setActiveGenerator={handleSelectGenerator}
        showAnswerKey={showAnswerKey}
        setShowAnswerKey={setShowAnswerKey}
        printSeparateKey={printSeparateKey}
        setPrintSeparateKey={setPrintSeparateKey}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onPrint={handleOpenPdfPrint}
        isGeneratingPdf={isGeneratingPdf}
        isDarkMode={isDarkMode}
        onToggleDarkMode={() => setIsDarkMode(d => !d)}
      />

      {/* Main Workspace Area */}
      <main id="printable-root" className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {/* Generator Quick Banner (hidden on print) */}
        <div className="no-print mb-4 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pb-2 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800 dark:text-slate-200">{currentGenMeta?.name}</span>
            <span>—</span>
            <span>{currentGenMeta?.description}</span>
          </div>
          <span className="hidden md:inline text-slate-400 dark:text-slate-500">
            Click <strong>Open PDF Print</strong> to view and print
          </span>
        </div>

        {/* Active Activity View */}
        {activeGenerator === 'word-search' && (
          <WordSearchView
            headerSettings={headerSettings}
            setHeaderSettings={setHeaderSettings}
            showAnswerKey={showAnswerKey}
            printSeparateKey={printSeparateKey}
          />
        )}

        {activeGenerator === 'crossword' && (
          <CrosswordView
            headerSettings={headerSettings}
            setHeaderSettings={setHeaderSettings}
            showAnswerKey={showAnswerKey}
            printSeparateKey={printSeparateKey}
          />
        )}

        {activeGenerator === 'bingo' && (
          <BingoView
            headerSettings={headerSettings}
            setHeaderSettings={setHeaderSettings}
            showAnswerKey={showAnswerKey}
          />
        )}

        {activeGenerator === 'word-scramble' && (
          <WordScrambleView
            headerSettings={headerSettings}
            setHeaderSettings={setHeaderSettings}
            showAnswerKey={showAnswerKey}
            printSeparateKey={printSeparateKey}
          />
        )}

        {activeGenerator === 'cryptogram' && (
          <CryptogramView
            headerSettings={headerSettings}
            setHeaderSettings={setHeaderSettings}
            showAnswerKey={showAnswerKey}
            printSeparateKey={printSeparateKey}
          />
        )}

        {activeGenerator === 'maze' && (
          <MazeView
            headerSettings={headerSettings}
            setHeaderSettings={setHeaderSettings}
            showAnswerKey={showAnswerKey}
            printSeparateKey={printSeparateKey}
          />
        )}

        {activeGenerator === 'matching' && (
          <MatchingView
            headerSettings={headerSettings}
            setHeaderSettings={setHeaderSettings}
            showAnswerKey={showAnswerKey}
            printSeparateKey={printSeparateKey}
          />
        )}

        {activeGenerator === 'sudoku' && (
          <SudokuView
            headerSettings={headerSettings}
            setHeaderSettings={setHeaderSettings}
            showAnswerKey={showAnswerKey}
            printSeparateKey={printSeparateKey}
          />
        )}

        {activeGenerator === 'word-ladder' && (
          <WordLadderView
            headerSettings={headerSettings}
            setHeaderSettings={setHeaderSettings}
            showAnswerKey={showAnswerKey}
            printSeparateKey={printSeparateKey}
          />
        )}

        {activeGenerator === 'fill-blank' && (
          <FillBlankView
            headerSettings={headerSettings}
            setHeaderSettings={setHeaderSettings}
            showAnswerKey={showAnswerKey}
          />
        )}
      </main>

      {/* Header and Style Customization Modal */}
      <HeaderSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={headerSettings}
        setSettings={setHeaderSettings}
        isDarkMode={isDarkMode}
      />

      {/* High-Resolution PDF Print & Export Modal */}
      <PdfPrintModal
        isOpen={isPdfModalOpen}
        onClose={() => setIsPdfModalOpen(false)}
        isGenerating={isGeneratingPdf}
        progressText={pdfProgressText}
        error={pdfError}
        pdfResult={pdfResult}
        onRetry={handleOpenPdfPrint}
        isDarkMode={isDarkMode}
      />
    </div>
  );
}
