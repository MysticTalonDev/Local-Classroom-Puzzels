import React from 'react';
import { HeaderSettings } from '../types.ts';
import { X, Sliders, Type, Palette } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  settings: HeaderSettings;
  setSettings: React.Dispatch<React.SetStateAction<HeaderSettings>>;
  isDarkMode?: boolean;
}

const COLOR_PRESETS = [
  { name: 'Charcoal Black', value: '#0f172a' },
  { name: 'Slate Blue', value: '#1e3a8a' },
  { name: 'Forest Green', value: '#065f46' },
  { name: 'Indigo Purple', value: '#4338ca' },
  { name: 'Crimson Red', value: '#991b1b' },
  { name: 'Warm Amber', value: '#b45309' },
];

export const HeaderSettingsModal: React.FC<Props> = ({
  isOpen,
  onClose,
  settings,
  setSettings,
  isDarkMode,
}) => {
  if (!isOpen) return null;

  return (
    <div className={`fixed inset-0 z-50 bg-slate-900/60 dark:bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 settings-modal-overlay ${isDarkMode ? 'dark' : ''}`}>
      <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh] text-slate-900 dark:text-slate-100 settings-modal-card">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <h3 className="font-bold text-slate-900 dark:text-slate-100 text-base">Worksheet Layout &amp; Theme Settings</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs">
          {/* Title & Subtitle */}
          <div className="space-y-3">
            <label className="block font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider text-[11px]">
              Page Headings
            </label>
            <div>
              <span className="text-slate-600 dark:text-slate-400 block mb-1 font-medium">Worksheet Title</span>
              <input
                type="text"
                value={settings.title}
                onChange={e => setSettings(s => ({ ...s, title: e.target.value }))}
                className="w-full p-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg text-xs text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
                placeholder="e.g. Science Activity Sheet"
              />
            </div>
            <div>
              <span className="text-slate-600 dark:text-slate-400 block mb-1 font-medium">Subtitle / Instructions</span>
              <textarea
                value={settings.subtitle}
                onChange={e => setSettings(s => ({ ...s, subtitle: e.target.value }))}
                rows={2}
                className="w-full p-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg text-xs text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
                placeholder="Instructions for the students..."
              />
            </div>
          </div>

          {/* Student Header Line Checkboxes */}
          <div className="space-y-2 pt-3 border-t border-slate-100 dark:border-slate-800">
            <label className="block font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider text-[11px]">
              Classroom Information Fields
            </label>
            <div className="grid grid-cols-2 gap-2 text-slate-700 dark:text-slate-300">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.showNameLine}
                  onChange={e => setSettings(s => ({ ...s, showNameLine: e.target.checked }))}
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <span>Name Line (Name: __)</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.showDateLine}
                  onChange={e => setSettings(s => ({ ...s, showDateLine: e.target.checked }))}
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <span>Date Line (Date: __)</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.showTeacherLine}
                  onChange={e => setSettings(s => ({ ...s, showTeacherLine: e.target.checked }))}
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <span>Class/Period Line</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.showScoreLine}
                  onChange={e => setSettings(s => ({ ...s, showScoreLine: e.target.checked }))}
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <span>Score Box ( __ / __ )</span>
              </label>
            </div>
          </div>

          {/* Typography & Fonts */}
          <div className="space-y-3 pt-3 border-t border-slate-100 dark:border-slate-800">
            <label className="block font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
              <Type className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
              Worksheet Typography
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'sans', label: 'Clean Sans-Serif' },
                { id: 'serif', label: 'Classic Book Serif' },
                { id: 'comic', label: 'Friendly School / Comic' },
                { id: 'mono', label: 'Typewriter Monospace' },
              ].map(f => (
                <button
                  key={f.id}
                  onClick={() => setSettings(s => ({ ...s, fontFamily: f.id as any }))}
                  className={`p-2 rounded-lg border text-left font-medium transition cursor-pointer ${
                    settings.fontFamily === f.id
                      ? 'border-indigo-600 bg-indigo-50/70 dark:bg-indigo-950/60 text-indigo-950 dark:text-indigo-200 font-bold'
                      : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="font-medium text-slate-700 dark:text-slate-300">Heading Size</span>
              <div className="flex gap-2">
                {(['sm', 'base', 'lg'] as const).map(sz => (
                  <button
                    key={sz}
                    onClick={() => setSettings(s => ({ ...s, fontSize: sz }))}
                    className={`px-3 py-1 rounded border uppercase text-[10px] font-bold cursor-pointer ${
                      settings.fontSize === sz
                        ? 'bg-indigo-600 text-white border-indigo-600'
                        : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700'
                    }`}
                  >
                    {sz}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Border & Accent Colors */}
          <div className="space-y-3 pt-3 border-t border-slate-100 dark:border-slate-800">
            <label className="block font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
              <Palette className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
              Border &amp; Divider Color
            </label>
            <div className="grid grid-cols-3 gap-2">
              {COLOR_PRESETS.map(c => (
                <button
                  key={c.value}
                  onClick={() => setSettings(s => ({ ...s, borderColor: c.value }))}
                  className={`flex items-center gap-2 p-2 rounded-lg border text-left transition cursor-pointer ${
                    settings.borderColor === c.value
                      ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 font-bold text-indigo-950 dark:text-indigo-200'
                      : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700'
                  }`}
                >
                  <span
                    className="w-3.5 h-3.5 rounded-full border border-black/20 flex-shrink-0"
                    style={{ backgroundColor: c.value }}
                  />
                  <span className="text-[11px] truncate">{c.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-100 dark:border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg text-xs transition cursor-pointer"
          >
            Apply &amp; Done
          </button>
        </div>
      </div>
    </div>
  );
};
