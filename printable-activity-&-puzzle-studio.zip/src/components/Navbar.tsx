import React from 'react';
import { GeneratorType } from '../types.ts';
import {
  Search,
  Grid3X3,
  CheckCircle2,
  Shuffle,
  KeyRound,
  Compass,
  Link2,
  TableProperties,
  ListOrdered,
  FileSpreadsheet,
  Printer,
  Eye,
  EyeOff,
  Sliders,
  Loader2,
  FileDown,
  Sun,
  Moon,
} from 'lucide-react';

interface Props {
  activeGenerator: GeneratorType;
  setActiveGenerator: (gen: GeneratorType) => void;
  showAnswerKey: boolean;
  setShowAnswerKey: (val: boolean) => void;
  printSeparateKey: boolean;
  setPrintSeparateKey: (val: boolean) => void;
  onOpenSettings: () => void;
  onPrint: () => void;
  isGeneratingPdf?: boolean;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
}

export const GENERATORS: {
  id: GeneratorType;
  name: string;
  shortName: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
}[] = [
  {
    id: 'word-search',
    name: 'Word Searches',
    shortName: 'Word Search',
    icon: Search,
    description: 'Custom dimensions & directional word placement',
  },
  {
    id: 'crossword',
    name: 'Crosswords',
    shortName: 'Crossword',
    icon: Grid3X3,
    description: 'Dynamic intersecting word & clue puzzle',
  },
  {
    id: 'bingo',
    name: 'Bingo Cards',
    shortName: 'Bingo Cards',
    icon: CheckCircle2,
    description: 'Multi-card randomized 5x5 classroom sheets',
  },
  {
    id: 'word-scramble',
    name: 'Word Scrambles',
    shortName: 'Word Scramble',
    icon: Shuffle,
    description: 'Jumbled letters with clues and write-in blanks',
  },
  {
    id: 'cryptogram',
    name: 'Cryptograms',
    shortName: 'Cryptogram',
    icon: KeyRound,
    description: 'Substitution ciphers with letter frequency checklist',
  },
  {
    id: 'maze',
    name: 'Maze Generator',
    shortName: 'Maze',
    icon: Compass,
    description: 'Perfect labyrinths with vector solution paths',
  },
  {
    id: 'matching',
    name: 'Matching Games',
    shortName: 'Matching',
    icon: Link2,
    description: 'Column connection & definition matching',
  },
  {
    id: 'sudoku',
    name: 'Custom Sudoku',
    shortName: 'Sudoku',
    icon: TableProperties,
    description: '9x9 logic grids with unique solution validation',
  },
  {
    id: 'word-ladder',
    name: 'Word Ladders',
    shortName: 'Word Ladder',
    icon: ListOrdered,
    description: 'Step-by-step 1-letter transformation rungs',
  },
  {
    id: 'fill-blank',
    name: 'Fill-in-the-Blank',
    shortName: 'Story Builder',
    icon: FileSpreadsheet,
    description: '2-page Mad-Libs style partner stories',
  },
];

export const Navbar: React.FC<Props> = ({
  activeGenerator,
  setActiveGenerator,
  showAnswerKey,
  setShowAnswerKey,
  printSeparateKey,
  setPrintSeparateKey,
  onOpenSettings,
  onPrint,
  isGeneratingPdf,
  isDarkMode,
  onToggleDarkMode,
}) => {
  return (
    <header className="no-print bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 sticky top-0 z-40 shadow-xs transition-colors">
      {/* Top Brand & Actions Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-4">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-sm font-black text-lg">
            P
          </div>
          <div>
            <h1 className="font-bold text-slate-900 dark:text-slate-100 text-base leading-tight tracking-tight">
              Printable Activity &amp; Puzzle Studio
            </h1>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
              10 Local Browser Activity Generators • Instant Print Formatting
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2.5 flex-wrap">
          {/* Answer Key Toggle */}
          <button
            onClick={() => setShowAnswerKey(!showAnswerKey)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition border cursor-pointer ${
              showAnswerKey
                ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 border-rose-200 dark:border-rose-800 hover:bg-rose-100 dark:hover:bg-rose-900/60'
                : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700'
            }`}
            title="Reveal solution on the worksheet"
          >
            {showAnswerKey ? <EyeOff className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" /> : <Eye className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />}
            <span>{showAnswerKey ? 'Hide Solution' : 'Show Answer Key'}</span>
          </button>

          {/* Print 2nd page key option */}
          <label className="hidden sm:flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-300 cursor-pointer select-none bg-slate-50 dark:bg-slate-800 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700">
            <input
              type="checkbox"
              checked={printSeparateKey}
              onChange={e => setPrintSeparateKey(e.target.checked)}
              className="rounded text-indigo-600 focus:ring-indigo-500 w-3.5 h-3.5"
            />
            <span>Print Key on Page 2</span>
          </label>

          {/* Customize Header & Styles */}
          <button
            onClick={onOpenSettings}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 transition cursor-pointer"
          >
            <Sliders className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
            <span>Customize Header</span>
          </button>

          {/* Dark Mode Switch */}
          <button
            type="button"
            role="switch"
            aria-checked={isDarkMode}
            onClick={onToggleDarkMode}
            className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition border cursor-pointer select-none ${
              isDarkMode
                ? 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
            title={isDarkMode ? 'Switch to Light mode' : 'Switch to Dark mode'}
            aria-label={isDarkMode ? 'Switch to Light mode' : 'Switch to Dark mode'}
          >
            {/* Visual Switch Track */}
            <span
              className={`w-7 h-4 rounded-full p-0.5 transition-colors duration-200 flex items-center ${
                isDarkMode ? 'bg-indigo-600 justify-end' : 'bg-slate-300 justify-start'
              }`}
            >
              <span className="w-3 h-3 rounded-full bg-white shadow-xs block" />
            </span>
            <span className="flex items-center gap-1">
              {isDarkMode ? (
                <>
                  <Moon className="w-3.5 h-3.5 text-indigo-400" />
                  <span className="hidden sm:inline">Dark</span>
                </>
              ) : (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-500" />
                  <span className="hidden sm:inline">Light</span>
                </>
              )}
            </span>
          </button>

          {/* Primary Print / PDF Button */}
          <button
            onClick={onPrint}
            disabled={isGeneratingPdf}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold text-white shadow-sm transition cursor-pointer ${
              isGeneratingPdf
                ? 'bg-indigo-400 cursor-wait'
                : 'bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800'
            }`}
            title="Open printable PDF & send to printer"
          >
            {isGeneratingPdf ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-white" />
                <span>Preparing PDF...</span>
              </>
            ) : (
              <>
                <Printer className="w-4 h-4" />
                <span>Open PDF Print</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Generator Tabs Navigation Bar */}
      <div className="border-t border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/90">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center gap-1 overflow-x-auto py-2 scrollbar-none">
            {GENERATORS.map(gen => {
              const Icon = gen.icon;
              const isActive = activeGenerator === gen.id;

              return (
                <button
                  key={gen.id}
                  onClick={() => setActiveGenerator(gen.id)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                    isActive
                      ? 'bg-white dark:bg-slate-800 text-indigo-700 dark:text-indigo-400 shadow-xs border border-slate-200 dark:border-slate-700 font-bold'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/60 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400 dark:text-slate-500'}`} />
                  <span>{gen.shortName}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </header>
  );
};
