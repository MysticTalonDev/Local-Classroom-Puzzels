import React, { useEffect, useRef } from 'react';
import {
  X,
  Printer,
  Download,
  ExternalLink,
  Loader2,
  FileCheck,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import { PdfGenerationResult } from '../utils/pdfExport.ts';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  isGenerating: boolean;
  progressText: string;
  error: string | null;
  pdfResult: PdfGenerationResult | null;
  onRetry: () => void;
  isDarkMode?: boolean;
}

export const PdfPrintModal: React.FC<Props> = ({
  isOpen,
  onClose,
  isGenerating,
  progressText,
  error,
  pdfResult,
  onRetry,
  isDarkMode,
}) => {
  const iframeRef = useRef<HTMLIFrameElement | null>(null);

  useEffect(() => {
    // Revoke object URL when closing or changing
    return () => {
      // Cleanup happens when component unmounts or parent resets
    };
  }, []);

  if (!isOpen) return null;

  const handleDownload = () => {
    if (!pdfResult) return;
    pdfResult.doc.save(pdfResult.filename);
  };

  const handleOpenInNewTab = () => {
    if (!pdfResult) return;
    try {
      const win = window.open(pdfResult.blobUrl, '_blank');
      if (!win) {
        // Fallback to direct anchor click
        const link = document.createElement('a');
        link.href = pdfResult.blobUrl;
        link.target = '_blank';
        link.click();
      }
    } catch {
      // Direct anchor fallback
      const link = document.createElement('a');
      link.href = pdfResult.blobUrl;
      link.target = '_blank';
      link.click();
    }
  };

  const handleDirectPrint = () => {
    if (!iframeRef.current || !pdfResult) {
      // Fallback to window.print()
      window.print();
      return;
    }

    try {
      const cw = iframeRef.current.contentWindow;
      if (cw) {
        cw.focus();
        cw.print();
      } else {
        window.print();
      }
    } catch {
      // In sandboxed iframes, window.open or download is the recommended way
      handleOpenInNewTab();
    }
  };

  return (
    <div className={`fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 no-print ${isDarkMode ? 'dark' : ''}`}>
      <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-4xl w-full h-[90vh] shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150">
        {/* Top Header Bar */}
        <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/90 dark:bg-slate-900/90 flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white">
              <Printer className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 dark:text-slate-100 text-sm flex items-center gap-2">
                <span>Worksheet PDF &amp; Print Preview</span>
                {pdfResult && (
                  <span className="text-[11px] font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-100/80 dark:bg-emerald-950/80 px-2 py-0.5 rounded-full flex items-center gap-1 border border-emerald-200 dark:border-emerald-800">
                    <FileCheck className="w-3 h-3" /> Ready
                  </span>
                )}
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                {pdfResult?.filename || 'Preparing high-resolution PDF document...'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Action Buttons if PDF is ready */}
            {pdfResult && (
              <>
                <button
                  onClick={handleDownload}
                  className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-semibold rounded-lg text-xs border border-slate-300 dark:border-slate-700 transition shadow-2xs cursor-pointer"
                  title="Download PDF to your computer"
                >
                  <Download className="w-3.5 h-3.5 text-slate-600 dark:text-slate-300" />
                  <span>Download PDF</span>
                </button>

                <button
                  onClick={handleOpenInNewTab}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-semibold rounded-lg text-xs border border-slate-300 dark:border-slate-700 transition shadow-2xs cursor-pointer"
                  title="Open PDF in a new browser tab for full native print options"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-slate-600 dark:text-slate-300" />
                  <span>Open in Tab</span>
                </button>

                <button
                  onClick={handleDirectPrint}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg text-xs transition shadow-2xs cursor-pointer"
                  title="Send to Printer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print</span>
                </button>
              </>
            )}

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-800 transition ml-1 cursor-pointer"
              title="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-grow bg-slate-200/70 dark:bg-slate-950 relative overflow-hidden flex flex-col items-center justify-center p-2 sm:p-4">
          {/* Loading State */}
          {isGenerating && (
            <div className="text-center p-8 bg-white dark:bg-slate-900 rounded-xl shadow-md border border-slate-200 dark:border-slate-800 max-w-sm w-full mx-auto space-y-3">
              <Loader2 className="w-8 h-8 text-indigo-600 dark:text-indigo-400 animate-spin mx-auto" />
              <div className="font-bold text-slate-800 dark:text-slate-100 text-sm">Rendering PDF Document</div>
              <p className="text-xs text-slate-500 dark:text-slate-400">{progressText || 'Capturing worksheet elements...'}</p>
            </div>
          )}

          {/* Error State */}
          {!isGenerating && error && (
            <div className="text-center p-6 bg-white dark:bg-slate-900 rounded-xl shadow-md border border-rose-200 dark:border-rose-900/60 max-w-md w-full mx-auto space-y-3">
              <AlertCircle className="w-8 h-8 text-rose-600 dark:text-rose-400 mx-auto" />
              <div className="font-bold text-slate-900 dark:text-slate-100 text-sm">Could not generate PDF</div>
              <p className="text-xs text-slate-600 dark:text-slate-300">{error}</p>
              <div className="pt-2 flex flex-wrap justify-center gap-2">
                <button
                  onClick={onRetry}
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg transition cursor-pointer"
                >
                  Try Again
                </button>
                <button
                  onClick={() => {
                    onClose();
                    window.print();
                  }}
                  className="px-4 py-1.5 bg-slate-800 dark:bg-slate-700 text-white text-xs font-semibold rounded-lg hover:bg-slate-900 dark:hover:bg-slate-600 transition flex items-center gap-1.5 cursor-pointer"
                  title="Print directly using browser print dialog"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Browser Print</span>
                </button>
                <button
                  onClick={onClose}
                  className="px-4 py-1.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {/* Success State: Embedded PDF Viewer */}
          {!isGenerating && pdfResult && (
            <div className="w-full h-full bg-white dark:bg-slate-900 rounded-lg shadow-inner overflow-hidden flex flex-col">
              <iframe
                ref={iframeRef}
                src={pdfResult.blobUrl}
                title="Worksheet PDF Preview"
                className="w-full flex-grow border-0"
              />
            </div>
          )}
        </div>

        {/* Footer Info Notice */}
        <div className="px-5 py-2.5 bg-slate-50 dark:bg-slate-900/90 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 gap-2 flex-shrink-0">
          <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-400">
            <HelpCircle className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
            <span>
              <strong>Tip:</strong> If your browser blocks the print dialog inside an iframe preview, click <strong>Open in Tab</strong> or <strong>Download PDF</strong> to print directly with zero restrictions.
            </span>
          </div>
          {pdfResult && (
            <button
              onClick={handleDownload}
              className="text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300 font-semibold underline sm:hidden cursor-pointer"
            >
              Download PDF ({pdfResult.filename})
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
