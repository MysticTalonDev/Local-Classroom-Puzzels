import React from 'react';

export const WorksheetFooter: React.FC = () => {
  return (
    <div className="mt-8 pt-3 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-400">
      <span>Printable Activity &amp; Puzzle Studio</span>
      <span>Page 1</span>
    </div>
  );
};
