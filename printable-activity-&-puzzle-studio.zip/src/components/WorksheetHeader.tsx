import React from 'react';
import { HeaderSettings } from '../types.ts';

interface WorksheetHeaderProps {
  settings: HeaderSettings;
  isAnswerKey?: boolean;
}

export const WorksheetHeader: React.FC<WorksheetHeaderProps> = ({
  settings,
  isAnswerKey = false,
}) => {
  const fontClass = {
    sans: 'font-sans-worksheet',
    serif: 'font-serif-worksheet',
    mono: 'font-mono-worksheet',
    comic: 'font-comic-worksheet',
  }[settings.fontFamily];

  const titleSizeClass = {
    sm: 'text-xl',
    base: 'text-2xl',
    lg: 'text-3xl',
  }[settings.fontSize];

  return (
    <div className={`mb-6 pb-4 border-b-2 ${fontClass}`} style={{ borderColor: settings.borderColor }}>
      {/* Student Meta Lines (Name, Date, Class/Teacher, Score) */}
      <div className="flex flex-wrap items-center justify-between gap-4 text-xs font-semibold text-slate-800 mb-4 pb-2 border-b border-slate-200">
        <div className="flex items-center gap-6 flex-wrap">
          {settings.showNameLine && (
            <div className="flex items-center gap-2">
              <span className="uppercase tracking-wider text-slate-500">Name:</span>
              <span className="inline-block w-44 border-b-2 border-slate-400"></span>
            </div>
          )}
          {settings.showDateLine && (
            <div className="flex items-center gap-2">
              <span className="uppercase tracking-wider text-slate-500">Date:</span>
              <span className="inline-block w-28 border-b-2 border-slate-400"></span>
            </div>
          )}
          {settings.showTeacherLine && (
            <div className="flex items-center gap-2">
              <span className="uppercase tracking-wider text-slate-500">Class/Period:</span>
              <span className="inline-block w-28 border-b-2 border-slate-400"></span>
            </div>
          )}
        </div>

        {settings.showScoreLine && (
          <div className="flex items-center gap-2">
            <span className="uppercase tracking-wider text-slate-500">Score:</span>
            <span className="inline-block px-2 py-0.5 border border-slate-400 rounded min-w-16 text-center">
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span>
          </div>
        )}
      </div>

      {/* Main Worksheet Title & Subtitle */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h1 className={`font-bold tracking-tight text-slate-900 ${titleSizeClass}`}>
              {settings.title || 'Activity Worksheet'}
            </h1>
            {isAnswerKey && (
              <span className="px-2.5 py-0.5 text-xs font-bold uppercase tracking-wider bg-rose-100 text-rose-800 border border-rose-300 rounded">
                Answer Key
              </span>
            )}
          </div>
          {settings.subtitle && (
            <p className="mt-1 text-xs text-slate-600 max-w-2xl leading-relaxed">
              {settings.subtitle}
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
