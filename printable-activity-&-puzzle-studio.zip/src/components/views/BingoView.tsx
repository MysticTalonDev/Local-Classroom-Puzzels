import React, { useState, useMemo } from 'react';
import { generateBingoCards, BingoOptions, BingoCard } from '../../generators/bingo.ts';
import { HeaderSettings } from '../../types.ts';
import { WorksheetHeader } from '../WorksheetHeader.tsx';
import { PRESETS } from '../../data/presets.ts';
import { RefreshCw, Bookmark, Sparkles, CheckSquare } from 'lucide-react';

interface Props {
  headerSettings: HeaderSettings;
  setHeaderSettings: React.Dispatch<React.SetStateAction<HeaderSettings>>;
  showAnswerKey: boolean;
}

export const BingoView: React.FC<Props> = ({
  headerSettings,
  setHeaderSettings,
}) => {
  const defaultPreset = PRESETS['bingo'][0];
  const [itemsInput, setItemsInput] = useState(defaultPreset.items.join('\n'));
  const [cardCount, setCardCount] = useState(defaultPreset.cardCount);
  const [freeSpaceText, setFreeSpaceText] = useState(defaultPreset.freeSpaceText);
  const [cardsPerPage, setCardsPerPage] = useState<1 | 2>(2);
  const [showCallerSheet, setShowCallerSheet] = useState(true);
  const [seed, setSeed] = useState(0);

  const items = useMemo(() => {
    return itemsInput
      .split('\n')
      .map(s => s.trim())
      .filter(s => s.length > 0);
  }, [itemsInput]);

  const result = useMemo(() => {
    const opts: BingoOptions = {
      items,
      cardCount,
      freeSpaceText,
      headerLetters: ['B', 'I', 'N', 'G', 'O'],
    };
    return generateBingoCards(opts);
  }, [items, cardCount, freeSpaceText, seed]);

  const handleApplyPreset = (idx: number) => {
    const preset = PRESETS['bingo'][idx];
    setItemsInput(preset.items.join('\n'));
    setCardCount(preset.cardCount);
    setFreeSpaceText(preset.freeSpaceText);
    setHeaderSettings(prev => ({
      ...prev,
      title: preset.title,
      subtitle: preset.subtitle,
    }));
    setSeed(s => s + 1);
  };

  const renderSingleBingoCard = (card: BingoCard) => {
    return (
      <div key={card.id} className="border-2 border-slate-900 rounded-lg overflow-hidden bg-white avoid-break shadow-sm mb-6">
        {/* Card Title & Header Letters */}
        <div className="bg-slate-900 text-white flex items-center justify-between px-3 py-1.5 border-b border-slate-900">
          <span className="text-xs font-bold uppercase tracking-wider">{headerSettings.title || 'Bingo'}</span>
          <span className="text-[10px] font-mono bg-slate-800 px-2 py-0.5 rounded text-slate-300">
            Card #{card.id}
          </span>
        </div>

        {/* B-I-N-G-O Columns Header */}
        <div className="grid grid-cols-5 bg-indigo-50 border-b-2 border-slate-900 text-center font-black text-indigo-950 text-sm py-1.5 tracking-wider">
          <div>B</div>
          <div>I</div>
          <div>N</div>
          <div>G</div>
          <div>O</div>
        </div>

        {/* 5x5 Grid */}
        <div className="grid grid-cols-5 divide-x divide-y divide-slate-400 bg-white">
          {card.grid.map((row, r) =>
            row.map((cell, c) => {
              const isFree = r === 2 && c === 2;
              return (
                <div
                  key={`${r}-${c}`}
                  className={`h-14 sm:h-16 p-1.5 flex items-center justify-center text-center leading-tight transition-colors ${
                    isFree
                      ? 'bg-amber-100/70 font-black text-amber-900 text-xs sm:text-sm uppercase tracking-wider'
                      : 'text-[11px] sm:text-xs font-semibold text-slate-800'
                  }`}
                >
                  <span className="line-clamp-3">{cell}</span>
                </div>
              );
            })
          )}
        </div>
      </div>
    );
  };

  // Group cards for printing layout
  const cardBatches = useMemo(() => {
    const batches: BingoCard[][] = [];
    for (let i = 0; i < result.cards.length; i += cardsPerPage) {
      batches.push(result.cards.slice(i, i + cardsPerPage));
    }
    return batches;
  }, [result.cards, cardsPerPage]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Controls */}
      <div className="lg:col-span-4 no-print bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-600" />
            Bingo Settings
          </h2>
          <button
            onClick={() => setSeed(s => s + 1)}
            className="flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-2.5 py-1 rounded transition"
          >
            <RefreshCw className="w-3 h-3" />
            Shuffle Cards
          </button>
        </div>

        {/* Presets */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
            <Bookmark className="w-3.5 h-3.5 text-slate-400" />
            Presets
          </label>
          <div className="grid grid-cols-1 gap-1.5 presets-container">
            {PRESETS['bingo'].map((p, idx) => (
              <button
                key={p.name}
                onClick={() => handleApplyPreset(idx)}
                className="preset-btn text-left px-3 py-2 text-xs rounded border border-slate-200 dark:border-slate-700/80 hover:border-indigo-300 hover:bg-indigo-50/50 transition flex items-center justify-between"
              >
                <span className="font-medium text-slate-800">{p.name}</span>
                <span className="text-[10px] text-slate-400">{p.items.length} items</span>
              </button>
            ))}
          </div>
        </div>

        {/* Word/Term List */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Words or Phrases (1 per line, min 24)
          </label>
          <textarea
            value={itemsInput}
            onChange={e => setItemsInput(e.target.value)}
            rows={5}
            className="w-full text-xs font-mono p-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            placeholder="Item 1&#10;Item 2&#10;..."
          />
          <p className="text-[11px] text-slate-400 mt-1">
            {items.length} unique items provided {items.length < 24 ? '(needs at least 24 for optimal diversity)' : '✓ Ready'}
          </p>
        </div>

        {/* Configuration Options */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Number of Cards: {cardCount}
            </label>
            <input
              type="number"
              min={1}
              max={30}
              value={cardCount}
              onChange={e => setCardCount(Math.min(30, Math.max(1, Number(e.target.value))))}
              className="w-full p-1.5 text-xs border border-slate-200 rounded-lg"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Center Free Tile Text
            </label>
            <input
              type="text"
              value={freeSpaceText}
              onChange={e => setFreeSpaceText(e.target.value)}
              className="w-full p-1.5 text-xs border border-slate-200 rounded-lg"
              placeholder="FREE"
            />
          </div>
        </div>

        {/* Layout & Caller Sheet */}
        <div className="space-y-2 pt-2 border-t border-slate-100">
          <label className="block text-xs font-semibold text-slate-700">Cards Per Printed Page</label>
          <div className="flex gap-3 text-xs">
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="radio"
                name="cardsPerPage"
                checked={cardsPerPage === 1}
                onChange={() => setCardsPerPage(1)}
              />
              <span>1 Card (Large)</span>
            </label>
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="radio"
                name="cardsPerPage"
                checked={cardsPerPage === 2}
                onChange={() => setCardsPerPage(2)}
              />
              <span>2 Cards (2-up)</span>
            </label>
          </div>

          <label className="flex items-center gap-2 pt-2 cursor-pointer text-xs font-medium text-slate-700">
            <input
              type="checkbox"
              checked={showCallerSheet}
              onChange={e => setShowCallerSheet(e.target.checked)}
              className="rounded text-indigo-600 focus:ring-indigo-500"
            />
            <span>Include Teacher Calling / Checklist Sheet</span>
          </label>
        </div>
      </div>

      {/* Printable Area */}
      <div className="lg:col-span-8 flex flex-col items-center">
        {/* Caller Checklist Sheet */}
        {showCallerSheet && (
          <div className="worksheet-paper mb-8">
            <WorksheetHeader settings={{ ...headerSettings, title: `${headerSettings.title || 'Bingo'} — Caller's Master Sheet`, subtitle: 'Mark off each term as you call it out to the class.' }} />
            <div className="my-4">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
                {result.callerItems.map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2 p-2 rounded bg-slate-50 border border-slate-200">
                    <CheckSquare className="w-4 h-4 text-slate-400 flex-shrink-0" />
                    <span className="font-semibold text-slate-800">{item}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="text-[11px] text-slate-400 mt-6 pt-3 border-t border-slate-200">
              Total items in draw pool: {result.callerItems.length}
            </div>
          </div>
        )}

        {/* Printable Bingo Cards */}
        {cardBatches.map((batch, bIdx) => (
          <div key={bIdx} className={`worksheet-paper mb-8 ${bIdx > 0 || showCallerSheet ? 'page-break' : ''}`}>
            <WorksheetHeader settings={headerSettings} />
            <div className="space-y-4">
              {batch.map(card => renderSingleBingoCard(card))}
            </div>
            <div className="text-[11px] text-slate-400 mt-4 text-center">
              Cut along borders to distribute individual cards
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
