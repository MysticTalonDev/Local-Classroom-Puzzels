import React, { useState, useMemo } from 'react';
import { generateCrossword, WordCluePair } from '../../generators/crossword.ts';
import { HeaderSettings } from '../../types.ts';
import { WorksheetHeader } from '../WorksheetHeader.tsx';
import { WorksheetFooter } from '../WorksheetFooter.tsx';
import { PRESETS } from '../../data/presets.ts';
import { RefreshCw, Bookmark, Sparkles, Plus, Trash2 } from 'lucide-react';

interface Props {
  headerSettings: HeaderSettings;
  setHeaderSettings: React.Dispatch<React.SetStateAction<HeaderSettings>>;
  showAnswerKey: boolean;
  printSeparateKey: boolean;
}

export const CrosswordView: React.FC<Props> = ({
  headerSettings,
  setHeaderSettings,
  showAnswerKey,
  printSeparateKey,
}) => {
  const defaultPreset = PRESETS['crossword'][0];
  const [pairs, setPairs] = useState<WordCluePair[]>(defaultPreset.pairs);
  const [seed, setSeed] = useState(0);

  const result = useMemo(() => {
    return generateCrossword(pairs);
  }, [pairs, seed]);

  const handleApplyPreset = (idx: number) => {
    const preset = PRESETS['crossword'][idx];
    setPairs([...preset.pairs]);
    setHeaderSettings(prev => ({
      ...prev,
      title: preset.title,
      subtitle: preset.subtitle,
    }));
    setSeed(s => s + 1);
  };

  const handleAddPair = () => {
    setPairs(prev => [...prev, { word: '', clue: '' }]);
  };

  const handleRemovePair = (index: number) => {
    setPairs(prev => prev.filter((_, i) => i !== index));
  };

  const handleUpdatePair = (index: number, field: 'word' | 'clue', val: string) => {
    setPairs(prev =>
      prev.map((item, i) => (i === index ? { ...item, [field]: val } : item))
    );
  };

  const renderGrid = (isKey: boolean) => {
    if (result.grid.length === 0) {
      return (
        <div className="p-8 text-center text-slate-400 text-sm italic">
          Add at least 2 word/clue pairs with intersecting letters to generate the crossword puzzle.
        </div>
      );
    }

    return (
      <div className="flex flex-col items-center my-4 overflow-x-auto">
        <div
          className="inline-grid border-2 border-slate-900 bg-slate-900 gap-[1px]"
          style={{
            gridTemplateColumns: `repeat(${result.cols}, minmax(0, 1fr))`,
          }}
        >
          {result.grid.map((row, r) =>
            row.map((cell, c) => {
              if (cell.isBlocked) {
                return (
                  <div
                    key={`${r}-${c}`}
                    className="w-7 h-7 sm:w-8 sm:h-8 bg-slate-900"
                  />
                );
              }

              return (
                <div
                  key={`${r}-${c}`}
                  className="w-7 h-7 sm:w-8 sm:h-8 bg-white relative flex items-center justify-center font-mono font-bold text-xs sm:text-sm text-slate-900 select-none"
                >
                  {cell.number && (
                    <span className="absolute top-0.5 left-0.5 text-[8px] font-sans font-bold leading-none text-slate-700">
                      {cell.number}
                    </span>
                  )}
                  <span className={isKey ? 'text-indigo-950 font-black' : 'opacity-0'}>
                    {cell.char}
                  </span>
                </div>
              );
            })
          )}
        </div>
      </div>
    );
  };

  const renderClues = (isKey: boolean) => {
    return (
      <div className="mt-6 pt-4 border-t border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-6 text-xs avoid-break">
        {/* Across Clues */}
        <div>
          <h3 className="font-bold uppercase tracking-wider text-slate-800 text-xs mb-2 pb-1 border-b border-slate-300">
            Across
          </h3>
          <div className="space-y-1.5">
            {result.acrossClues.map(clue => (
              <div key={clue.number} className="flex items-start gap-1.5 leading-tight">
                <span className="font-bold text-slate-900 min-w-5">{clue.number}.</span>
                <span className="text-slate-700">
                  {clue.clue}
                  {isKey && (
                    <span className="ml-1.5 font-bold font-mono text-indigo-700">
                      ({clue.answer})
                    </span>
                  )}
                </span>
              </div>
            ))}
            {result.acrossClues.length === 0 && (
              <span className="text-slate-400 italic">No across clues in this layout.</span>
            )}
          </div>
        </div>

        {/* Down Clues */}
        <div>
          <h3 className="font-bold uppercase tracking-wider text-slate-800 text-xs mb-2 pb-1 border-b border-slate-300">
            Down
          </h3>
          <div className="space-y-1.5">
            {result.downClues.map(clue => (
              <div key={clue.number} className="flex items-start gap-1.5 leading-tight">
                <span className="font-bold text-slate-900 min-w-5">{clue.number}.</span>
                <span className="text-slate-700">
                  {clue.clue}
                  {isKey && (
                    <span className="ml-1.5 font-bold font-mono text-indigo-700">
                      ({clue.answer})
                    </span>
                  )}
                </span>
              </div>
            ))}
            {result.downClues.length === 0 && (
              <span className="text-slate-400 italic">No down clues in this layout.</span>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Control Panel */}
      <div className="lg:col-span-4 no-print bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-600" />
            Crossword Builder
          </h2>
          <button
            onClick={() => setSeed(s => s + 1)}
            className="flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-2.5 py-1 rounded transition"
          >
            <RefreshCw className="w-3 h-3" />
            Rebuild Grid
          </button>
        </div>

        {/* Preset Selector */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
            <Bookmark className="w-3.5 h-3.5 text-slate-400" />
            Presets
          </label>
          <div className="grid grid-cols-1 gap-1.5 presets-container">
            {PRESETS['crossword'].map((p, idx) => (
              <button
                key={p.name}
                onClick={() => handleApplyPreset(idx)}
                className="preset-btn text-left px-3 py-2 text-xs rounded border border-slate-200 dark:border-slate-700/80 hover:border-indigo-300 hover:bg-indigo-50/50 transition flex items-center justify-between"
              >
                <span className="font-medium text-slate-800">{p.name}</span>
                <span className="text-[10px] text-slate-400">{p.pairs.length} clues</span>
              </button>
            ))}
          </div>
        </div>

        {/* Word : Clue Editor */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-semibold text-slate-700">
              Words &amp; Clues ({pairs.length})
            </label>
            <button
              onClick={handleAddPair}
              className="flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-700"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Clue
            </button>
          </div>

          <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
            {pairs.map((pair, idx) => (
              <div key={idx} className="p-2 border border-slate-200 rounded-lg bg-slate-50 space-y-1.5">
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={pair.word}
                    onChange={e => handleUpdatePair(idx, 'word', e.target.value)}
                    placeholder="ANSWER"
                    className="w-1/2 p-1.5 text-xs font-mono font-bold uppercase border border-slate-200 rounded bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                  <button
                    onClick={() => handleRemovePair(idx)}
                    className="ml-auto text-slate-400 hover:text-rose-600 p-1 transition"
                    title="Delete item"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
                <input
                  type="text"
                  value={pair.clue}
                  onChange={e => handleUpdatePair(idx, 'clue', e.target.value)}
                  placeholder="Clue for this word..."
                  className="w-full p-1.5 text-xs border border-slate-200 rounded bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Printable Paper */}
      <div className="lg:col-span-8 flex flex-col items-center">
        <div className="worksheet-paper">
          <WorksheetHeader settings={headerSettings} isAnswerKey={showAnswerKey} />
          {renderGrid(showAnswerKey)}
          {renderClues(showAnswerKey)}
          <WorksheetFooter />
        </div>

        {printSeparateKey && !showAnswerKey && (
          <div className="worksheet-paper mt-8 page-break">
            <WorksheetHeader settings={headerSettings} isAnswerKey={true} />
            {renderGrid(true)}
            {renderClues(true)}
            <WorksheetFooter />
          </div>
        )}
      </div>
    </div>
  );
};
