import React, { useState, useMemo } from 'react';
import { generateCryptogram, CryptogramOptions } from '../../generators/cryptogram.ts';
import { HeaderSettings } from '../../types.ts';
import { WorksheetHeader } from '../WorksheetHeader.tsx';
import { WorksheetFooter } from '../WorksheetFooter.tsx';
import { PRESETS } from '../../data/presets.ts';
import { RefreshCw, Bookmark, Sparkles } from 'lucide-react';

interface Props {
  headerSettings: HeaderSettings;
  setHeaderSettings: React.Dispatch<React.SetStateAction<HeaderSettings>>;
  showAnswerKey: boolean;
  printSeparateKey: boolean;
}

export const CryptogramView: React.FC<Props> = ({
  headerSettings,
  setHeaderSettings,
  showAnswerKey,
  printSeparateKey,
}) => {
  const defaultPreset = PRESETS['cryptogram'][0];
  const [quote, setQuote] = useState(defaultPreset.quote);
  const [author, setAuthor] = useState(defaultPreset.author);
  const [hintsCount, setHintsCount] = useState(defaultPreset.hintsCount);
  const [showFrequencyTable, setShowFrequencyTable] = useState(true);
  const [seed, setSeed] = useState(0);

  const result = useMemo(() => {
    const opts: CryptogramOptions = {
      quote,
      author,
      revealedHintsCount: hintsCount,
    };
    return generateCryptogram(opts);
  }, [quote, author, hintsCount, seed]);

  const handleApplyPreset = (idx: number) => {
    const preset = PRESETS['cryptogram'][idx];
    setQuote(preset.quote);
    setAuthor(preset.author);
    setHintsCount(preset.hintsCount);
    setHeaderSettings(prev => ({
      ...prev,
      title: preset.title,
      subtitle: preset.subtitle,
    }));
    setSeed(s => s + 1);
  };

  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

  const renderCipherQuote = (isKey: boolean) => {
    return (
      <div className="my-6 space-y-6">
        {/* Word Boxes Flow */}
        <div className="flex flex-wrap gap-x-5 gap-y-6 items-end leading-loose">
          {result.words.map((word, wIdx) => (
            <div key={wIdx} className="flex gap-1.5 avoid-break">
              {word.boxes.map((box, bIdx) => {
                if (!box.isLetter) {
                  return (
                    <div
                      key={bIdx}
                      className="w-4 flex flex-col items-center justify-end pb-1 font-mono font-bold text-slate-700 text-sm"
                    >
                      <span>{box.originalChar}</span>
                    </div>
                  );
                }

                return (
                  <div key={bIdx} className="flex flex-col items-center">
                    {/* Encrypted Letter */}
                    <span className="font-mono font-bold text-slate-800 text-xs sm:text-sm tracking-wider mb-1 select-none">
                      {box.cipherChar}
                    </span>

                    {/* Write-in Underline with Solved letter or Blank */}
                    <div
                      className={`w-6 sm:w-7 h-7 sm:h-8 border-b-2 flex items-center justify-center font-mono font-black text-xs sm:text-sm transition-colors ${
                        isKey
                          ? 'border-indigo-600 text-indigo-700 bg-indigo-50/50'
                          : box.isRevealedHint
                          ? 'border-emerald-600 text-emerald-700 bg-emerald-50/40'
                          : 'border-slate-700 bg-transparent'
                      }`}
                    >
                      {isKey ? box.originalChar : box.isRevealedHint ? box.originalChar : ''}
                    </div>
                  </div>
                );
              })}
            </div>
          ))}
        </div>

        {/* Author Credit */}
        {result.author && (
          <div className="text-right text-xs italic font-semibold text-slate-600 pt-2">
            — {result.author}
          </div>
        )}

        {/* Clue Hints */}
        {result.hints.length > 0 && (
          <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 flex items-center gap-3">
            <span className="font-bold uppercase tracking-wider text-[10px] bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded">
              Free Clue:
            </span>
            <div className="flex gap-4 font-mono font-bold">
              {result.hints.map((h, i) => (
                <span key={i}>
                  {h.cipher} = {h.plain}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Letter Frequency Table */}
        {showFrequencyTable && (
          <div className="pt-4 border-t border-slate-200 avoid-break">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600">
                Letter Frequency Checklist (Occurrences in Cipher)
              </span>
              <span className="text-[10px] text-slate-400">Track and cross off decrypted letters</span>
            </div>
            <div className="grid grid-cols-13 gap-1 text-center font-mono">
              {alphabet.map(ch => {
                const count = result.frequencyMap[ch] || 0;
                return (
                  <div
                    key={ch}
                    className={`p-1 border rounded text-[10px] ${
                      count > 0 ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-white border-slate-200 text-slate-300'
                    }`}
                  >
                    <div className="font-bold">{ch}</div>
                    <div className="text-[9px] text-slate-500">{count}</div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Controls */}
      <div className="lg:col-span-4 no-print bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-600" />
            Cryptogram Cipher
          </h2>
          <button
            onClick={() => setSeed(s => s + 1)}
            className="flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-2.5 py-1 rounded transition"
          >
            <RefreshCw className="w-3 h-3" />
            New Cipher Key
          </button>
        </div>

        {/* Presets */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
            <Bookmark className="w-3.5 h-3.5 text-slate-400" />
            Historic Quote Presets
          </label>
          <div className="grid grid-cols-1 gap-1.5 presets-container">
            {PRESETS['cryptogram'].map((p, idx) => (
              <button
                key={p.name}
                onClick={() => handleApplyPreset(idx)}
                className="preset-btn text-left px-3 py-2 text-xs rounded border border-slate-200 dark:border-slate-700/80 hover:border-indigo-300 hover:bg-indigo-50/50 transition flex items-center justify-between"
              >
                <span className="font-medium text-slate-800">{p.name}</span>
                <span className="text-[10px] text-slate-400">{p.author}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Custom Quote Input */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Quote or Sentence to Encrypt
          </label>
          <textarea
            value={quote}
            onChange={e => setQuote(e.target.value)}
            rows={4}
            className="w-full text-xs font-mono p-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 uppercase"
            placeholder="ENTER YOUR SECRET QUOTE OR MESSAGE..."
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Author / Attribution (optional)
          </label>
          <input
            type="text"
            value={author}
            onChange={e => setAuthor(e.target.value)}
            className="w-full p-2 text-xs border border-slate-200 rounded-lg"
            placeholder="e.g. Albert Einstein"
          />
        </div>

        {/* Hints & Frequency Controls */}
        <div className="space-y-3 pt-2 border-t border-slate-100">
          <div>
            <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
              <span>Revealed Letter Clues: {hintsCount}</span>
            </div>
            <input
              type="range"
              min={0}
              max={3}
              value={hintsCount}
              onChange={e => setHintsCount(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
            />
          </div>

          <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700">
            <input
              type="checkbox"
              checked={showFrequencyTable}
              onChange={e => setShowFrequencyTable(e.target.checked)}
              className="rounded text-indigo-600 focus:ring-indigo-500"
            />
            <span>Include Letter Frequency Analysis Table</span>
          </label>
        </div>
      </div>

      {/* Printable Area */}
      <div className="lg:col-span-8 flex flex-col items-center">
        <div className="worksheet-paper">
          <WorksheetHeader settings={headerSettings} isAnswerKey={showAnswerKey} />
          {renderCipherQuote(showAnswerKey)}
          <WorksheetFooter />
        </div>

        {printSeparateKey && !showAnswerKey && (
          <div className="worksheet-paper mt-8 page-break">
            <WorksheetHeader settings={headerSettings} isAnswerKey={true} />
            {renderCipherQuote(true)}
            <WorksheetFooter />
          </div>
        )}
      </div>
    </div>
  );
};
