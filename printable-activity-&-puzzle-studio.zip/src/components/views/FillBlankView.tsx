import React, { useState, useMemo } from 'react';
import { generateFillInTheBlank } from '../../generators/fillInTheBlank.ts';
import { HeaderSettings } from '../../types.ts';
import { WorksheetHeader } from '../WorksheetHeader.tsx';
import { WorksheetFooter } from '../WorksheetFooter.tsx';
import { PRESETS } from '../../data/presets.ts';
import { Bookmark, Sparkles, FileText } from 'lucide-react';

interface Props {
  headerSettings: HeaderSettings;
  setHeaderSettings: React.Dispatch<React.SetStateAction<HeaderSettings>>;
  showAnswerKey: boolean;
}

export const FillBlankView: React.FC<Props> = ({
  headerSettings,
  setHeaderSettings,
}) => {
  const defaultPreset = PRESETS['fill-blank'][0];
  const [rawStory, setRawStory] = useState(defaultPreset.story);
  const [activeTab, setActiveTab] = useState<'both' | 'part1' | 'part2'>('both');

  const result = useMemo(() => {
    return generateFillInTheBlank(rawStory, headerSettings.title);
  }, [rawStory, headerSettings.title]);

  const handleApplyPreset = (idx: number) => {
    const preset = PRESETS['fill-blank'][idx];
    setRawStory(preset.story);
    setHeaderSettings(prev => ({
      ...prev,
      title: preset.title,
      subtitle: preset.subtitle,
    }));
  };

  const renderPart1PromptSheet = () => {
    return (
      <div className="worksheet-paper mb-8">
        <WorksheetHeader
          settings={{
            ...headerSettings,
            title: `${headerSettings.title || 'Story Builder'} — Part 1: Player Word List`,
            subtitle: 'INSTRUCTIONS: Player 1, ask your partner for the following types of words without showing them the story! Write their answers on the lines below.',
          }}
        />

        <div className="my-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4">
            {result.prompts.map(prompt => (
              <div
                key={prompt.id}
                className="flex items-end justify-between gap-3 pb-1 border-b-2 border-slate-700 avoid-break"
              >
                <div className="flex items-baseline gap-2">
                  <span className="font-bold text-slate-900 text-xs min-w-5">
                    {prompt.id}.
                  </span>
                  <span className="text-xs font-semibold text-slate-600 capitalize">
                    {prompt.placeholderText}:
                  </span>
                </div>
                <div className="flex-grow min-w-28 text-xs font-mono font-bold text-indigo-900 text-right pr-2">
                  {/* Space for student to write in */}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-8 p-3 rounded bg-amber-50 border border-amber-200 text-xs text-amber-900 avoid-break">
          Once all {result.prompts.length} words above are filled in, turn to <strong>Part 2</strong> and transfer the words into the matching numbered story blanks to read the hilarious tale!
        </div>

        <WorksheetFooter />
      </div>
    );
  };

  const renderPart2StorySheet = () => {
    return (
      <div className="worksheet-paper page-break mb-8">
        <WorksheetHeader
          settings={{
            ...headerSettings,
            title: `${headerSettings.title || 'Story Builder'} — Part 2: The Story`,
            subtitle: 'Now read the story aloud, filling in the numbered blanks with the corresponding words from Part 1!',
          }}
        />

        <div className="my-8 text-sm sm:text-base leading-loose text-slate-800 tracking-wide font-serif-worksheet avoid-break">
          {result.segments.map((seg, idx) => {
            if (seg.type === 'text') {
              return <span key={idx}>{seg.content}</span>;
            }

            return (
              <span key={idx} className="inline-flex flex-col items-center mx-1 align-baseline">
                {/* Blank line for writing */}
                <span className="inline-block min-w-28 border-b-2 border-slate-900 text-center font-sans-worksheet text-xs font-bold text-indigo-900 px-2 pb-0.5">
                  &nbsp;
                </span>
                <span className="text-[10px] font-sans font-semibold text-slate-500 tracking-normal uppercase leading-none mt-1">
                  #{seg.promptId} ({seg.label})
                </span>
              </span>
            );
          })}
        </div>

        <WorksheetFooter />
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Controls */}
      <div className="lg:col-span-4 no-print bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-600" />
            Fill-in-the-Blank Story
          </h2>
        </div>

        {/* Presets */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
            <Bookmark className="w-3.5 h-3.5 text-slate-400" />
            Story Presets
          </label>
          <div className="grid grid-cols-1 gap-1.5 presets-container">
            {PRESETS['fill-blank'].map((p, idx) => (
              <button
                key={p.name}
                onClick={() => handleApplyPreset(idx)}
                className="preset-btn text-left px-3 py-2 text-xs rounded border border-slate-200 dark:border-slate-700/80 hover:border-indigo-300 hover:bg-indigo-50/50 transition flex items-center justify-between"
              >
                <span className="font-medium text-slate-800">{p.name}</span>
                <span className="text-[10px] text-slate-400">Mad-Libs style</span>
              </button>
            ))}
          </div>
        </div>

        {/* Story Textarea */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Story Template (Use [brackets] for word prompts)
          </label>
          <textarea
            value={rawStory}
            onChange={e => setRawStory(e.target.value)}
            rows={8}
            className="w-full text-xs p-2.5 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 leading-relaxed font-sans"
            placeholder="Yesterday I saw a [adjective] [animal]..."
          />
          <p className="text-[11px] text-slate-400 mt-1">
            {result.prompts.length} blanks detected in this story.
          </p>
        </div>

        {/* Page Preview Switcher on screen */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1.5">
            Screen View Filter
          </label>
          <div className="grid grid-cols-3 gap-1.5 text-xs">
            <button
              onClick={() => setActiveTab('both')}
              className={`p-2 rounded border font-medium ${
                activeTab === 'both' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-slate-50 text-slate-700 border-slate-200'
              }`}
            >
              Both Pages
            </button>
            <button
              onClick={() => setActiveTab('part1')}
              className={`p-2 rounded border font-medium ${
                activeTab === 'part1' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-slate-50 text-slate-700 border-slate-200'
              }`}
            >
              Part 1 Only
            </button>
            <button
              onClick={() => setActiveTab('part2')}
              className={`p-2 rounded border font-medium ${
                activeTab === 'part2' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-slate-50 text-slate-700 border-slate-200'
              }`}
            >
              Part 2 Only
            </button>
          </div>
        </div>

        <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600 space-y-1">
          <p className="font-semibold text-slate-800 flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-indigo-600" />
            2-Page Classroom Activity
          </p>
          <p>
            When printed, Part 1 (word collector sheet) prints on Page 1 and Part 2 (full story with blanks) prints cleanly on Page 2 with automatic page breaks.
          </p>
        </div>
      </div>

      {/* Printable Area */}
      <div className="lg:col-span-8 flex flex-col items-center">
        {(activeTab === 'both' || activeTab === 'part1') && renderPart1PromptSheet()}
        {(activeTab === 'both' || activeTab === 'part2') && renderPart2StorySheet()}
      </div>
    </div>
  );
};
