import React, { useState, useMemo } from 'react';
import { generateMatchingWorksheet, MatchingPair } from '../../generators/matching.ts';
import { HeaderSettings } from '../../types.ts';
import { WorksheetHeader } from '../WorksheetHeader.tsx';
import { WorksheetFooter } from '../WorksheetFooter.tsx';
import { PRESETS } from '../../data/presets.ts';
import { RefreshCw, Bookmark, Sparkles, Plus, Trash2 } from 'lucide-react';

interface Props {
  headerSettings: HeaderSettings;
  setHeaderSettings: React.Dispatch<React.SetStateAction<HeaderSettings>>;
  showAnswerKey: boolean;
  printSeparateKey: boolean;
}

export const MatchingView: React.FC<Props> = ({
  headerSettings,
  setHeaderSettings,
  showAnswerKey,
  printSeparateKey,
}) => {
  const defaultPreset = PRESETS['matching'][0];
  const [pairs, setPairs] = useState<MatchingPair[]>(defaultPreset.pairs);
  const [showConnectorDots, setShowConnectorDots] = useState(true);
  const [seed, setSeed] = useState(0);

  const result = useMemo(() => {
    return generateMatchingWorksheet(pairs);
  }, [pairs, seed]);

  const handleApplyPreset = (idx: number) => {
    const preset = PRESETS['matching'][idx];
    setPairs([...preset.pairs]);
    setHeaderSettings(prev => ({
      ...prev,
      title: preset.title,
      subtitle: preset.subtitle,
    }));
    setSeed(s => s + 1);
  };

  const handleAddPair = () => {
    setPairs(prev => [...prev, { left: '', right: '' }]);
  };

  const handleRemovePair = (index: number) => {
    setPairs(prev => prev.filter((_, i) => i !== index));
  };

  const handleUpdatePair = (index: number, field: 'left' | 'right', val: string) => {
    setPairs(prev =>
      prev.map((item, i) => (i === index ? { ...item, [field]: val } : item))
    );
  };

  const renderColumns = (isKey: boolean) => {
    return (
      <div className="my-6">
        <div className="grid grid-cols-2 gap-8 sm:gap-12 relative">
          {/* Column A */}
          <div className="space-y-4">
            <h3 className="font-bold text-xs uppercase tracking-wider text-slate-800 pb-1 border-b border-slate-300">
              Column A
            </h3>
            {result.columnA.map(item => (
              <div
                key={item.index}
                className="flex items-center justify-between p-2.5 rounded border border-slate-200 bg-slate-50/70 text-xs min-h-12 avoid-break"
              >
                <div className="flex items-center gap-2.5 pr-2">
                  {/* Matching write-in letter box */}
                  <div
                    className={`w-7 h-7 rounded border-2 flex items-center justify-center font-bold text-xs font-mono transition-colors flex-shrink-0 ${
                      isKey
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-800'
                        : 'bg-white border-slate-400 text-slate-800'
                    }`}
                  >
                    {isKey ? item.correctLetter : ''}
                  </div>
                  <span className="font-bold text-slate-900 min-w-4">{item.index}.</span>
                  <span className="font-medium text-slate-800 leading-snug">{item.text}</span>
                </div>

                {showConnectorDots && (
                  <div className="w-3 h-3 rounded-full border-2 border-slate-400 bg-white flex-shrink-0 ml-1" />
                )}
              </div>
            ))}
          </div>

          {/* Column B */}
          <div className="space-y-4">
            <h3 className="font-bold text-xs uppercase tracking-wider text-slate-800 pb-1 border-b border-slate-300">
              Column B
            </h3>
            {result.columnB.map(item => (
              <div
                key={item.letter}
                className="flex items-center justify-between p-2.5 rounded border border-slate-200 bg-white text-xs min-h-12 avoid-break"
              >
                {showConnectorDots && (
                  <div className="w-3 h-3 rounded-full border-2 border-slate-400 bg-white flex-shrink-0 mr-2" />
                )}

                <div className="flex items-center gap-2 flex-grow">
                  <span className="font-bold font-mono text-indigo-900 bg-indigo-50 px-1.5 py-0.5 rounded border border-indigo-200">
                    {item.letter}.
                  </span>
                  <span className="text-slate-700 leading-snug">{item.text}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Answer Key Summary Box if key enabled */}
        {isKey && (
          <div className="mt-8 p-3 rounded-lg bg-indigo-50 border border-indigo-200 avoid-break">
            <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-900 mb-2">
              Answer Key Solutions:
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono font-bold text-indigo-950">
              {result.columnA.map(a => (
                <div key={a.index} className="p-1 bg-white rounded border border-indigo-100">
                  {a.index} = {a.correctLetter} ({a.text.slice(0, 14)}...)
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Control Panel */}
      <div className="lg:col-span-4 no-print bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-600" />
            Matching Worksheet
          </h2>
          <button
            onClick={() => setSeed(s => s + 1)}
            className="flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-2.5 py-1 rounded transition"
          >
            <RefreshCw className="w-3 h-3" />
            Shuffle Column B
          </button>
        </div>

        {/* Presets */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
            <Bookmark className="w-3.5 h-3.5 text-slate-400" />
            Presets
          </label>
          <div className="grid grid-cols-1 gap-1.5 presets-container">
            {PRESETS['matching'].map((p, idx) => (
              <button
                key={p.name}
                onClick={() => handleApplyPreset(idx)}
                className="preset-btn text-left px-3 py-2 text-xs rounded border border-slate-200 dark:border-slate-700/80 hover:border-indigo-300 hover:bg-indigo-50/50 transition flex items-center justify-between"
              >
                <span className="font-medium text-slate-800">{p.name}</span>
                <span className="text-[10px] text-slate-400">{p.pairs.length} pairs</span>
              </button>
            ))}
          </div>
        </div>

        {/* Options */}
        <div className="pt-2 border-t border-slate-100">
          <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700">
            <input
              type="checkbox"
              checked={showConnectorDots}
              onChange={e => setShowConnectorDots(e.target.checked)}
              className="rounded text-indigo-600 focus:ring-indigo-500"
            />
            <span>Include Physical Line-Connector Dots (●)</span>
          </label>
        </div>

        {/* Pairs List */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-semibold text-slate-700">
              Matching Pairs ({pairs.length})
            </label>
            <button
              onClick={handleAddPair}
              className="flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-700"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Pair
            </button>
          </div>

          <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
            {pairs.map((pair, idx) => (
              <div key={idx} className="p-2 border border-slate-200 rounded-lg bg-slate-50 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-slate-500">Pair #{idx + 1}</span>
                  <button
                    onClick={() => handleRemovePair(idx)}
                    className="text-slate-400 hover:text-rose-600 p-0.5"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
                <input
                  type="text"
                  value={pair.left}
                  onChange={e => handleUpdatePair(idx, 'left', e.target.value)}
                  placeholder="Column A item (e.g. Japan)"
                  className="w-full p-1.5 text-xs font-medium border border-slate-200 rounded bg-white"
                />
                <input
                  type="text"
                  value={pair.right}
                  onChange={e => handleUpdatePair(idx, 'right', e.target.value)}
                  placeholder="Column B match (e.g. Tokyo)"
                  className="w-full p-1.5 text-xs border border-slate-200 rounded bg-white"
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Printable Paper */}
      <div className="lg:col-span-8 flex flex-col items-center">
        <div className="worksheet-paper">
          <WorksheetHeader settings={headerSettings} isAnswerKey={showAnswerKey} />
          {renderColumns(showAnswerKey)}
          <WorksheetFooter />
        </div>

        {printSeparateKey && !showAnswerKey && (
          <div className="worksheet-paper mt-8 page-break">
            <WorksheetHeader settings={headerSettings} isAnswerKey={true} />
            {renderColumns(true)}
            <WorksheetFooter />
          </div>
        )}
      </div>
    </div>
  );
};
