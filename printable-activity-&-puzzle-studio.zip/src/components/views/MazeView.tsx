import React, { useState, useMemo } from 'react';
import { generateMaze, MazeOptions } from '../../generators/maze.ts';
import { HeaderSettings } from '../../types.ts';
import { WorksheetHeader } from '../WorksheetHeader.tsx';
import { WorksheetFooter } from '../WorksheetFooter.tsx';
import { PRESETS } from '../../data/presets.ts';
import { RefreshCw, Bookmark, Sparkles } from 'lucide-react';

interface Props {
  headerSettings: HeaderSettings;
  setHeaderSettings: React.Dispatch<React.SetStateAction<HeaderSettings>>;
  showAnswerKey: boolean;
  printSeparateKey: boolean;
}

export const MazeView: React.FC<Props> = ({
  headerSettings,
  setHeaderSettings,
  showAnswerKey,
  printSeparateKey,
}) => {
  const defaultPreset = PRESETS['maze'][0];
  const [cols, setCols] = useState(defaultPreset.cols);
  const [rows, setRows] = useState(defaultPreset.rows);
  const [seed, setSeed] = useState(0);

  const result = useMemo(() => {
    const opts: MazeOptions = { cols, rows };
    return generateMaze(opts);
  }, [cols, rows, seed]);

  const handleApplyPreset = (idx: number) => {
    const preset = PRESETS['maze'][idx];
    setCols(preset.cols);
    setRows(preset.rows);
    setHeaderSettings(prev => ({
      ...prev,
      title: preset.title,
      subtitle: preset.subtitle,
    }));
    setSeed(s => s + 1);
  };

  const renderMazeSVG = (isKey: boolean) => {
    const cellSize = 22; // px
    const svgWidth = result.cols * cellSize;
    const svgHeight = result.rows * cellSize;

    // Build SVG path segments for walls
    const wallSegments: string[] = [];

    for (let r = 0; r < result.rows; r++) {
      for (let c = 0; c < result.cols; c++) {
        const cell = result.grid[r][c];
        const x1 = c * cellSize;
        const y1 = r * cellSize;
        const x2 = x1 + cellSize;
        const y2 = y1 + cellSize;

        if (cell.top) {
          wallSegments.push(`M ${x1} ${y1} L ${x2} ${y1}`);
        }
        if (cell.right) {
          wallSegments.push(`M ${x2} ${y1} L ${x2} ${y2}`);
        }
        if (cell.bottom) {
          wallSegments.push(`M ${x1} ${y2} L ${x2} ${y2}`);
        }
        if (cell.left) {
          wallSegments.push(`M ${x1} ${y1} L ${x1} ${y2}`);
        }
      }
    }

    // Build solution polyline points
    const solutionPoints = result.solutionPath
      .map(p => `${p.col * cellSize + cellSize / 2},${p.row * cellSize + cellSize / 2}`)
      .join(' ');

    return (
      <div className="flex flex-col items-center my-6">
        {/* Entrance / Start label */}
        <div className="flex items-center gap-2 mb-2 text-xs font-bold text-emerald-800 uppercase tracking-wider">
          <span>▼ Start Entrance</span>
        </div>

        <div className="p-3 bg-white border-2 border-slate-800 rounded-lg shadow-sm">
          <svg
            width={svgWidth}
            height={svgHeight}
            className="max-w-full h-auto block"
            style={{ shapeRendering: 'crispEdges' }}
          >
            {/* Background */}
            <rect width={svgWidth} height={svgHeight} fill="#ffffff" />

            {/* Start Marker Box */}
            <rect
              x={0}
              y={0}
              width={cellSize}
              height={cellSize}
              fill="#d1fae5"
              fillOpacity={0.6}
            />

            {/* End Marker Box */}
            <rect
              x={(result.cols - 1) * cellSize}
              y={(result.rows - 1) * cellSize}
              width={cellSize}
              height={cellSize}
              fill="#fee2e2"
              fillOpacity={0.6}
            />

            {/* Solution Path if enabled */}
            {isKey && (
              <polyline
                points={solutionPoints}
                fill="none"
                stroke="#dc2626"
                strokeWidth={Math.max(2.5, cellSize / 5)}
                strokeLinecap="round"
                strokeLinejoin="round"
                style={{ shapeRendering: 'geometricPrecision' }}
              />
            )}

            {/* Maze Walls */}
            <path
              d={wallSegments.join(' ')}
              stroke="#0f172a"
              strokeWidth="2.5"
              strokeLinecap="square"
              fill="none"
            />
          </svg>
        </div>

        {/* Exit / Goal label */}
        <div className="flex items-center gap-2 mt-2 text-xs font-bold text-rose-800 uppercase tracking-wider">
          <span>▲ Exit Goal (★)</span>
        </div>
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Controls */}
      <div className="lg:col-span-4 no-print bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-600" />
            Maze Settings
          </h2>
          <button
            onClick={() => setSeed(s => s + 1)}
            className="flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-2.5 py-1 rounded transition"
          >
            <RefreshCw className="w-3 h-3" />
            Generate New Maze
          </button>
        </div>

        {/* Presets */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
            <Bookmark className="w-3.5 h-3.5 text-slate-400" />
            Complexity Presets
          </label>
          <div className="grid grid-cols-1 gap-1.5 presets-container">
            {PRESETS['maze'].map((p, idx) => (
              <button
                key={p.name}
                onClick={() => handleApplyPreset(idx)}
                className="preset-btn text-left px-3 py-2 text-xs rounded border border-slate-200 dark:border-slate-700/80 hover:border-indigo-300 hover:bg-indigo-50/50 transition flex items-center justify-between"
              >
                <span className="font-medium text-slate-800">{p.name}</span>
                <span className="text-[10px] text-slate-400">{p.cols}x{p.rows}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Dimension Sliders */}
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
              <span>Columns (Width): {cols}</span>
            </div>
            <input
              type="range"
              min={8}
              max={32}
              value={cols}
              onChange={e => setCols(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
              <span>Rows (Height): {rows}</span>
            </div>
            <input
              type="range"
              min={8}
              max={32}
              value={rows}
              onChange={e => setRows(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
            />
          </div>
        </div>

        <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600 space-y-1">
          <p className="font-semibold text-slate-800">Recursive Backtracking Algorithm</p>
          <p>
            Generates a perfect labyrinth with exactly one continuous unique solution path from entrance to exit. No loops or inaccessible areas.
          </p>
        </div>
      </div>

      {/* Printable Area */}
      <div className="lg:col-span-8 flex flex-col items-center">
        <div className="worksheet-paper">
          <WorksheetHeader settings={headerSettings} isAnswerKey={showAnswerKey} />
          {renderMazeSVG(showAnswerKey)}
          <WorksheetFooter />
        </div>

        {printSeparateKey && !showAnswerKey && (
          <div className="worksheet-paper mt-8 page-break">
            <WorksheetHeader settings={headerSettings} isAnswerKey={true} />
            {renderMazeSVG(true)}
            <WorksheetFooter />
          </div>
        )}
      </div>
    </div>
  );
};
