import React, { useState, useMemo } from 'react';
import { generateSudoku, SudokuDifficulty } from '../../generators/sudoku.ts';
import { HeaderSettings } from '../../types.ts';
import { WorksheetHeader } from '../WorksheetHeader.tsx';
import { WorksheetFooter } from '../WorksheetFooter.tsx';
import { PRESETS } from '../../data/presets.ts';
import { RefreshCw, Bookmark, Sparkles } from 'lucide-react';

interface Props {
  headerSettings: HeaderSettings;
  setHeaderSettings: React.Dispatch<React.SetStateAction<HeaderSettings>>;
  showAnswerKey: boolean;
  printSeparateKey: boolean;
}

export const SudokuView: React.FC<Props> = ({
  headerSettings,
  setHeaderSettings,
  showAnswerKey,
  printSeparateKey,
}) => {
  const [difficulty, setDifficulty] = useState<SudokuDifficulty>('medium');
  const [seed, setSeed] = useState(0);

  const result = useMemo(() => {
    return generateSudoku(difficulty);
  }, [difficulty, seed]);

  const handleApplyPreset = (idx: number) => {
    const preset = PRESETS['sudoku'][idx];
    setDifficulty(preset.difficulty);
    setHeaderSettings(prev => ({
      ...prev,
      title: preset.title,
      subtitle: preset.subtitle,
    }));
    setSeed(s => s + 1);
  };

  const renderSudokuGrid = (isKey: boolean) => {
    return (
      <div className="flex flex-col items-center my-6">
        <div className="border-4 border-slate-900 bg-slate-900 inline-block shadow-sm">
          <div className="grid grid-cols-9 gap-[1px] bg-slate-400">
            {result.puzzle.map((row, r) =>
              row.map((cellValue, c) => {
                const solutionValue = result.solution[r][c];
                const isGiven = cellValue !== null;

                // Thicker borders on 3x3 block edges
                const borderBottom = (r + 1) % 3 === 0 && r !== 8 ? 'border-b-2 border-b-slate-900' : '';
                const borderRight = (c + 1) % 3 === 0 && c !== 8 ? 'border-r-2 border-r-slate-900' : '';

                return (
                  <div
                    key={`${r}-${c}`}
                    className={`w-9 h-9 sm:w-11 sm:h-11 flex items-center justify-center font-bold text-base sm:text-lg select-none bg-white ${borderBottom} ${borderRight}`}
                  >
                    {isGiven ? (
                      <span className="text-slate-950 font-black">{cellValue}</span>
                    ) : isKey ? (
                      <span className="text-indigo-600 font-semibold">{solutionValue}</span>
                    ) : (
                      <span className="opacity-0">0</span>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Digit Checklist for students */}
        <div className="mt-8 pt-4 border-t border-slate-200 w-full max-w-md avoid-break">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span className="font-semibold uppercase tracking-wider">Digit Checklist (1-9)</span>
            <span>Difficulty: <strong className="capitalize text-slate-700">{difficulty}</strong> ({result.cluesCount} starting clues)</span>
          </div>
          <div className="grid grid-cols-9 gap-2 text-center font-mono">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
              <div key={num} className="p-1.5 border border-slate-300 rounded bg-slate-50 text-xs">
                <div className="font-bold text-slate-800">{num}</div>
                <div className="w-3 h-3 mx-auto mt-1 border border-slate-300 rounded-sm bg-white" />
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Controls */}
      <div className="lg:col-span-4 no-print bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-600" />
            Sudoku Generator
          </h2>
          <button
            onClick={() => setSeed(s => s + 1)}
            className="flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-2.5 py-1 rounded transition"
          >
            <RefreshCw className="w-3 h-3" />
            New Board
          </button>
        </div>

        {/* Presets */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
            <Bookmark className="w-3.5 h-3.5 text-slate-400" />
            Difficulty Presets
          </label>
          <div className="grid grid-cols-1 gap-1.5 presets-container">
            {PRESETS['sudoku'].map((p, idx) => (
              <button
                key={p.name}
                onClick={() => handleApplyPreset(idx)}
                className="preset-btn text-left px-3 py-2 text-xs rounded border border-slate-200 dark:border-slate-700/80 hover:border-indigo-300 hover:bg-indigo-50/50 transition flex items-center justify-between"
              >
                <span className="font-medium text-slate-800">{p.name}</span>
                <span className="text-[10px] text-slate-400 capitalize">{p.difficulty}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Difficulty Level Buttons */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-2">
            Target Difficulty Level
          </label>
          <div className="grid grid-cols-2 gap-2">
            {(['easy', 'medium', 'hard', 'expert'] as SudokuDifficulty[]).map(diff => (
              <button
                key={diff}
                onClick={() => {
                  setDifficulty(diff);
                  setSeed(s => s + 1);
                }}
                className={`px-3 py-2 rounded-lg text-xs font-bold capitalize transition border ${
                  difficulty === diff
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                    : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/50'
                }`}
              >
                {diff}
              </button>
            ))}
          </div>
        </div>

        <div className="p-3 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-lg text-xs text-slate-600 dark:text-slate-300 space-y-1">
          <p className="font-semibold text-slate-800 dark:text-slate-200">Unique-Solution Backtracking Algorithm</p>
          <p>
            Generates fully solvable Sudoku grids with symmetrical number knockout guaranteeing exactly one unique solution.
          </p>
        </div>
      </div>

      {/* Printable Area */}
      <div className="lg:col-span-8 flex flex-col items-center">
        <div className="worksheet-paper">
          <WorksheetHeader settings={headerSettings} isAnswerKey={showAnswerKey} />
          {renderSudokuGrid(showAnswerKey)}
          <WorksheetFooter />
        </div>

        {printSeparateKey && !showAnswerKey && (
          <div className="worksheet-paper mt-8 page-break">
            <WorksheetHeader settings={headerSettings} isAnswerKey={true} />
            {renderSudokuGrid(true)}
            <WorksheetFooter />
          </div>
        )}
      </div>
    </div>
  );
};
