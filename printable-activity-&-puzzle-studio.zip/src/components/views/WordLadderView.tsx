import React, { useState, useMemo } from 'react';
import { generateWordLadder } from '../../generators/wordLadder.ts';
import { HeaderSettings } from '../../types.ts';
import { WorksheetHeader } from '../WorksheetHeader.tsx';
import { WorksheetFooter } from '../WorksheetFooter.tsx';
import { PRESETS } from '../../data/presets.ts';
import { Bookmark, Sparkles, AlertCircle, ArrowDown } from 'lucide-react';

interface Props {
  headerSettings: HeaderSettings;
  setHeaderSettings: React.Dispatch<React.SetStateAction<HeaderSettings>>;
  showAnswerKey: boolean;
  printSeparateKey: boolean;
}

export const WordLadderView: React.FC<Props> = ({
  headerSettings,
  setHeaderSettings,
  showAnswerKey,
  printSeparateKey,
}) => {
  const defaultPreset = PRESETS['word-ladder'][0];
  const [startWord, setStartWord] = useState(defaultPreset.start);
  const [endWord, setEndWord] = useState(defaultPreset.end);
  const [showStepHints, setShowStepHints] = useState(true);

  const result = useMemo(() => {
    return generateWordLadder(startWord, endWord);
  }, [startWord, endWord]);

  const handleApplyPreset = (idx: number) => {
    const preset = PRESETS['word-ladder'][idx];
    setStartWord(preset.start);
    setEndWord(preset.end);
    setHeaderSettings(prev => ({
      ...prev,
      title: preset.title,
      subtitle: preset.subtitle,
    }));
  };

  const renderLadder = (isKey: boolean) => {
    if (!result.success) {
      return (
        <div className="p-8 my-6 bg-rose-50 border border-rose-200 rounded-lg text-rose-800 text-xs flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-rose-600 flex-shrink-0" />
          <span>{result.errorMessage}</span>
        </div>
      );
    }

    return (
      <div className="flex flex-col items-center my-6">
        <div className="w-full max-w-sm relative">
          {/* Ladder Side Rails Graphic */}
          <div className="absolute left-6 top-2 bottom-2 w-1.5 bg-slate-400 rounded-full" />
          <div className="absolute right-6 top-2 bottom-2 w-1.5 bg-slate-400 rounded-full" />

          {/* Steps / Rungs */}
          <div className="space-y-4 relative z-10 py-2">
            {result.steps.map((step, idx) => {
              const isStart = idx === 0;
              const isEnd = idx === result.steps.length - 1;
              const isMiddle = !isStart && !isEnd;

              return (
                <div key={idx} className="flex flex-col items-center avoid-break">
                  {/* Step container representing a ladder rung */}
                  <div
                    className={`w-full mx-auto px-6 py-2.5 rounded-lg border-2 flex items-center justify-between shadow-xs transition-colors ${
                      isStart
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-950'
                        : isEnd
                        ? 'bg-amber-50 border-amber-500 text-amber-950'
                        : 'bg-white border-slate-700 text-slate-900'
                    }`}
                  >
                    {/* Step label / Number */}
                    <span className="font-bold text-xs uppercase tracking-wider text-slate-500 min-w-16">
                      {isStart ? 'Start' : isEnd ? 'Target' : `Step ${step.stepNumber}`}
                    </span>

                    {/* Word Letters Box */}
                    <div className="flex items-center gap-1.5 font-mono font-black text-base sm:text-lg tracking-widest">
                      {step.word.split('').map((char, charIdx) => {
                        const isChangedLetter = charIdx === step.letterChangedIndex;

                        if (isMiddle && !isKey) {
                          return (
                            <div
                              key={charIdx}
                              className={`w-8 h-8 border-b-2 flex items-end justify-center pb-0.5 text-sm font-bold ${
                                isChangedLetter ? 'border-indigo-600 bg-indigo-50/50' : 'border-slate-800 bg-slate-50'
                              }`}
                            >
                              <span className="opacity-0">{char}</span>
                            </div>
                          );
                        }

                        return (
                          <div
                            key={charIdx}
                            className={`w-8 h-8 flex items-center justify-center rounded border ${
                              isKey && isMiddle
                                ? isChangedLetter
                                  ? 'bg-indigo-100 border-indigo-500 text-indigo-900 font-black'
                                  : 'bg-slate-50 border-slate-300 text-slate-700'
                                : isStart || isEnd
                                ? 'bg-transparent border-transparent'
                                : 'bg-white border-slate-300'
                            }`}
                          >
                            {char}
                          </div>
                        );
                      })}
                    </div>

                    {/* Hint indicator */}
                    <div className="text-[11px] text-slate-400 min-w-16 text-right">
                      {showStepHints && step.hint && (
                        <span className="text-indigo-600 font-medium">{step.hint}</span>
                      )}
                    </div>
                  </div>

                  {/* Connecting Arrow */}
                  {idx < result.steps.length - 1 && (
                    <ArrowDown className="w-3.5 h-3.5 text-slate-400 my-0.5" />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Rules Box at the bottom */}
        <div className="mt-6 pt-4 border-t border-slate-200 text-xs text-slate-500 text-center max-w-md avoid-break">
          <strong>Rules:</strong> On each rung, change exactly ONE letter to form a real English dictionary word, gradually climbing from {result.startWord} to {result.endWord}!
        </div>
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Controls */}
      <div className="lg:col-span-4 no-print bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-600" />
            Word Ladder Builder
          </h2>
        </div>

        {/* Presets */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
            <Bookmark className="w-3.5 h-3.5 text-slate-400" />
            Popular Word Ladder Challenges
          </label>
          <div className="grid grid-cols-1 gap-1.5 presets-container">
            {PRESETS['word-ladder'].map((p, idx) => (
              <button
                key={p.name}
                onClick={() => handleApplyPreset(idx)}
                className="preset-btn text-left px-3 py-2 text-xs rounded border border-slate-200 dark:border-slate-700/80 hover:border-indigo-300 hover:bg-indigo-50/50 transition flex items-center justify-between"
              >
                <span className="font-medium text-slate-800">{p.name}</span>
                <span className="text-[10px] text-slate-400">{p.start.length} letters</span>
              </button>
            ))}
          </div>
        </div>

        {/* Custom Start & End */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Start Word
            </label>
            <input
              type="text"
              value={startWord}
              onChange={e => setStartWord(e.target.value.toUpperCase())}
              maxLength={6}
              className="w-full p-2 text-sm font-mono font-bold uppercase border border-slate-200 rounded-lg text-center"
              placeholder="COLD"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Target End Word
            </label>
            <input
              type="text"
              value={endWord}
              onChange={e => setEndWord(e.target.value.toUpperCase())}
              maxLength={6}
              className="w-full p-2 text-sm font-mono font-bold uppercase border border-slate-200 rounded-lg text-center"
              placeholder="WARM"
            />
          </div>
        </div>

        {/* Options */}
        <div className="pt-2 border-t border-slate-100">
          <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700">
            <input
              type="checkbox"
              checked={showStepHints}
              onChange={e => setShowStepHints(e.target.checked)}
              className="rounded text-indigo-600 focus:ring-indigo-500"
            />
            <span>Print Step Clues (e.g. &quot;Change letter #2&quot;)</span>
          </label>
        </div>

        <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600 space-y-1">
          <p className="font-semibold text-slate-800">Breadth-First Search (BFS) Solver</p>
          <p>
            Finds the absolute shortest path across our internal 1,500+ common word dictionary.
          </p>
        </div>
      </div>

      {/* Printable Area */}
      <div className="lg:col-span-8 flex flex-col items-center">
        <div className="worksheet-paper">
          <WorksheetHeader settings={headerSettings} isAnswerKey={showAnswerKey} />
          {renderLadder(showAnswerKey)}
          <WorksheetFooter />
        </div>

        {printSeparateKey && !showAnswerKey && (
          <div className="worksheet-paper mt-8 page-break">
            <WorksheetHeader settings={headerSettings} isAnswerKey={true} />
            {renderLadder(true)}
            <WorksheetFooter />
          </div>
        )}
      </div>
    </div>
  );
};
