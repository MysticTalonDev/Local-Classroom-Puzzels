import React, { useState, useMemo } from 'react';
import { generateWordScramble } from '../../generators/wordScramble.ts';
import { HeaderSettings } from '../../types.ts';
import { WorksheetHeader } from '../WorksheetHeader.tsx';
import { WorksheetFooter } from '../WorksheetFooter.tsx';
import { PRESETS } from '../../data/presets.ts';
import { RefreshCw, Bookmark, Sparkles, Plus, Trash2 } from 'lucide-react';

interface Props {
  headerSettings: HeaderSettings;
  setHeaderSettings: React.Dispatch<React.SetStateAction<HeaderSettings>>;
  showAnswerKey: boolean;
  printSeparateKey: boolean;
}

export const WordScrambleView: React.FC<Props> = ({
  headerSettings,
  setHeaderSettings,
  showAnswerKey,
  printSeparateKey,
}) => {
  const defaultPreset = PRESETS['word-scramble'][0];
  const [items, setItems] = useState<{ word: string; clue?: string }[]>(defaultPreset.items);
  const [showCluesOnSheet, setShowCluesOnSheet] = useState(true);
  const [showLetterBoxes, setShowLetterBoxes] = useState(true);
  const [seed, setSeed] = useState(0);

  const result = useMemo(() => {
    return generateWordScramble(items);
  }, [items, seed]);

  const handleApplyPreset = (idx: number) => {
    const preset = PRESETS['word-scramble'][idx];
    setItems([...preset.items]);
    setHeaderSettings(prev => ({
      ...prev,
      title: preset.title,
      subtitle: preset.subtitle,
    }));
    setSeed(s => s + 1);
  };

  const handleAddItem = () => {
    setItems(prev => [...prev, { word: '', clue: '' }]);
  };

  const handleRemoveItem = (index: number) => {
    setItems(prev => prev.filter((_, i) => i !== index));
  };

  const handleUpdateItem = (index: number, field: 'word' | 'clue', val: string) => {
    setItems(prev =>
      prev.map((item, i) => (i === index ? { ...item, [field]: val } : item))
    );
  };

  const renderScrambleList = (isKey: boolean) => {
    return (
      <div className="space-y-4 my-6">
        {result.items.map((item, idx) => (
          <div
            key={idx}
            className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 rounded-lg border border-slate-200 bg-slate-50/50 avoid-break"
          >
            {/* Scrambled Word & Optional Clue */}
            <div className="flex items-start gap-3">
              <span className="font-bold text-slate-400 text-sm min-w-6 pt-0.5">
                {idx + 1}.
              </span>
              <div>
                <div className="font-mono font-black text-slate-900 tracking-[0.25em] text-base sm:text-lg">
                  {item.scrambled}
                </div>
                {showCluesOnSheet && item.clue && (
                  <p className="text-xs text-slate-500 mt-0.5 italic">
                    Hint: {item.clue}
                  </p>
                )}
              </div>
            </div>

            {/* Answer write-in boxes / lines */}
            <div className="flex items-center gap-1.5 flex-shrink-0">
              {isKey ? (
                <div className="font-mono font-bold text-emerald-800 text-sm tracking-wider px-3 py-1 bg-emerald-50 border border-emerald-300 rounded">
                  {item.original}
                </div>
              ) : showLetterBoxes ? (
                <div className="flex gap-1">
                  {item.original.split('').map((char, charIdx) => {
                    if (char === ' ') {
                      return <span key={charIdx} className="w-3" />;
                    }
                    return (
                      <div
                        key={charIdx}
                        className="w-7 h-8 border-b-2 border-slate-700 bg-white flex items-end justify-center pb-0.5 text-sm font-bold font-mono"
                      />
                    );
                  })}
                </div>
              ) : (
                <div className="w-44 border-b-2 border-slate-700 h-8" />
              )}
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Control Panel */}
      <div className="lg:col-span-4 no-print bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-600" />
            Word Scramble Controls
          </h2>
          <button
            onClick={() => setSeed(s => s + 1)}
            className="flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-2.5 py-1 rounded transition"
          >
            <RefreshCw className="w-3 h-3" />
            Reshuffle Letters
          </button>
        </div>

        {/* Presets */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
            <Bookmark className="w-3.5 h-3.5 text-slate-400" />
            Presets
          </label>
          <div className="grid grid-cols-1 gap-1.5 presets-container">
            {PRESETS['word-scramble'].map((p, idx) => (
              <button
                key={p.name}
                onClick={() => handleApplyPreset(idx)}
                className="preset-btn text-left px-3 py-2 text-xs rounded border border-slate-200 dark:border-slate-700/80 hover:border-indigo-300 hover:bg-indigo-50/50 transition flex items-center justify-between"
              >
                <span className="font-medium text-slate-800">{p.name}</span>
                <span className="text-[10px] text-slate-400">{p.items.length} words</span>
              </button>
            ))}
          </div>
        </div>

        {/* Worksheet Display Options */}
        <div className="space-y-2 pt-2 border-t border-slate-100">
          <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700">
            <input
              type="checkbox"
              checked={showCluesOnSheet}
              onChange={e => setShowCluesOnSheet(e.target.checked)}
              className="rounded text-indigo-600 focus:ring-indigo-500"
            />
            <span>Print Clue / Hint Subtitles</span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700">
            <input
              type="checkbox"
              checked={showLetterBoxes}
              onChange={e => setShowLetterBoxes(e.target.checked)}
              className="rounded text-indigo-600 focus:ring-indigo-500"
            />
            <span>Show Individual Letter Blanks (_ _ _)</span>
          </label>
        </div>

        {/* Item List */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-semibold text-slate-700">
              Scramble Words ({items.length})
            </label>
            <button
              onClick={handleAddItem}
              className="flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-700"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Word
            </button>
          </div>

          <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
            {items.map((item, idx) => (
              <div key={idx} className="p-2 border border-slate-200 rounded-lg bg-slate-50 space-y-1">
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={item.word}
                    onChange={e => handleUpdateItem(idx, 'word', e.target.value)}
                    placeholder="WORD"
                    className="w-1/2 p-1.5 text-xs font-mono font-bold uppercase border border-slate-200 rounded bg-white"
                  />
                  <button
                    onClick={() => handleRemoveItem(idx)}
                    className="ml-auto text-slate-400 hover:text-rose-600 p-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
                <input
                  type="text"
                  value={item.clue || ''}
                  onChange={e => handleUpdateItem(idx, 'clue', e.target.value)}
                  placeholder="Optional hint / clue..."
                  className="w-full p-1 text-xs border border-slate-200 rounded bg-white"
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Printable Paper */}
      <div className="lg:col-span-8 flex flex-col items-center">
        <div className="worksheet-paper">
          <WorksheetHeader settings={headerSettings} isAnswerKey={showAnswerKey} />
          {renderScrambleList(showAnswerKey)}
          <WorksheetFooter />
        </div>

        {printSeparateKey && !showAnswerKey && (
          <div className="worksheet-paper mt-8 page-break">
            <WorksheetHeader settings={headerSettings} isAnswerKey={true} />
            {renderScrambleList(true)}
            <WorksheetFooter />
          </div>
        )}
      </div>
    </div>
  );
};
