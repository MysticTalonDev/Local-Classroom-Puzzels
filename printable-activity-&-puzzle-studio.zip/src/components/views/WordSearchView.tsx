import React, { useState, useMemo } from 'react';
import { generateWordSearch, WordSearchOptions } from '../../generators/wordSearch.ts';
import { HeaderSettings } from '../../types.ts';
import { WorksheetHeader } from '../WorksheetHeader.tsx';
import { WorksheetFooter } from '../WorksheetFooter.tsx';
import { PRESETS } from '../../data/presets.ts';
import { RefreshCw, Bookmark, Sparkles, AlertCircle } from 'lucide-react';

interface Props {
  headerSettings: HeaderSettings;
  setHeaderSettings: React.Dispatch<React.SetStateAction<HeaderSettings>>;
  showAnswerKey: boolean;
  printSeparateKey: boolean;
}

export const WordSearchView: React.FC<Props> = ({
  headerSettings,
  setHeaderSettings,
  showAnswerKey,
  printSeparateKey,
}) => {
  const defaultPreset = PRESETS['word-search'][0];
  const [wordsInput, setWordsInput] = useState(defaultPreset.words.join(', '));
  const [width, setWidth] = useState(defaultPreset.width);
  const [height, setHeight] = useState(defaultPreset.height);
  const [allowHorizontal, setAllowHorizontal] = useState(defaultPreset.allowHorizontal);
  const [allowVertical, setAllowVertical] = useState(defaultPreset.allowVertical);
  const [allowDiagonal, setAllowDiagonal] = useState(defaultPreset.allowDiagonal);
  const [allowReverse, setAllowReverse] = useState(defaultPreset.allowReverse);
  const [seed, setSeed] = useState(0);

  const wordList = useMemo(() => {
    return wordsInput
      .split(/[\n,]+/)
      .map(w => w.trim().toUpperCase())
      .filter(w => w.length >= 2);
  }, [wordsInput]);

  const result = useMemo(() => {
    const opts: WordSearchOptions = {
      words: wordList,
      width,
      height,
      allowHorizontal,
      allowVertical,
      allowDiagonal,
      allowReverse,
    };
    return generateWordSearch(opts);
  }, [wordList, width, height, allowHorizontal, allowVertical, allowDiagonal, allowReverse, seed]);

  const handleApplyPreset = (idx: number) => {
    const preset = PRESETS['word-search'][idx];
    setWordsInput(preset.words.join(', '));
    setWidth(preset.width);
    setHeight(preset.height);
    setAllowHorizontal(preset.allowHorizontal);
    setAllowVertical(preset.allowVertical);
    setAllowDiagonal(preset.allowDiagonal);
    setAllowReverse(preset.allowReverse);
    setHeaderSettings(prev => ({
      ...prev,
      title: preset.title,
      subtitle: preset.subtitle,
    }));
    setSeed(s => s + 1);
  };

  // Map of coordinates to highlighted words for answer key
  const answerCoords = useMemo(() => {
    const map = new Set<string>();
    result.placedWords.forEach(pw => {
      pw.path.forEach(([r, c]) => map.add(`${r},${c}`));
    });
    return map;
  }, [result]);

  const renderGrid = (isKey: boolean) => {
    return (
      <div className="flex flex-col items-center my-4">
        <div
          className="inline-grid gap-[1px] p-2 bg-slate-300 rounded border border-slate-400 select-none"
          style={{
            gridTemplateColumns: `repeat(${result.width}, minmax(0, 1fr))`,
          }}
        >
          {result.grid.map((row, r) =>
            row.map((char, c) => {
              const isAnswer = isKey && answerCoords.has(`${r},${c}`);
              return (
                <div
                  key={`${r}-${c}`}
                  className={`w-7 h-7 sm:w-8 sm:h-8 flex items-center justify-center font-mono font-bold text-xs sm:text-sm rounded-[2px] transition-colors ${
                    isAnswer
                      ? 'bg-amber-200 text-amber-950 font-black border border-amber-400'
                      : 'bg-white text-slate-800'
                  }`}
                >
                  {char}
                </div>
              );
            })
          )}
        </div>
      </div>
    );
  };

  const renderWordBank = () => {
    return (
      <div className="mt-6 pt-4 border-t border-slate-200 avoid-break">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
            Word Bank ({result.placedWords.length} words hidden)
          </h3>
          <span className="text-[11px] text-slate-500">Cross out each word as you locate it</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 text-xs">
          {result.placedWords.map((pw, i) => (
            <div key={i} className="flex items-center gap-2 p-1.5 rounded bg-slate-50 border border-slate-200">
              <span className="w-3.5 h-3.5 rounded border border-slate-400 flex-shrink-0"></span>
              <span className="font-semibold tracking-wider font-mono text-slate-800">{pw.word}</span>
            </div>
          ))}
        </div>

        {result.unplacedWords.length > 0 && (
          <div className="mt-3 p-2 bg-amber-50 border border-amber-200 rounded text-amber-800 text-xs flex items-center gap-2 no-print">
            <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0" />
            <span>
              {result.unplacedWords.length} words could not fit in the current grid dimensions ({result.unplacedWords.join(', ')}). Try increasing grid size or toggling reverse/diagonal!
            </span>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Control Panel (Sidebar on desktop, hidden on print) */}
      <div className="lg:col-span-4 no-print bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-600" />
            Word Search Controls
          </h2>
          <button
            onClick={() => setSeed(s => s + 1)}
            className="flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-2.5 py-1 rounded transition"
          >
            <RefreshCw className="w-3 h-3" />
            Reshuffle
          </button>
        </div>

        {/* Preset Selector */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
            <Bookmark className="w-3.5 h-3.5 text-slate-400" />
            Educational Presets
          </label>
          <div className="grid grid-cols-1 gap-1.5 presets-container">
            {PRESETS['word-search'].map((p, idx) => (
              <button
                key={p.name}
                onClick={() => handleApplyPreset(idx)}
                className="preset-btn text-left px-3 py-2 text-xs rounded border border-slate-200 dark:border-slate-700/80 hover:border-indigo-300 hover:bg-indigo-50/50 transition flex items-center justify-between"
              >
                <span className="font-medium text-slate-800">{p.name}</span>
                <span className="text-[10px] text-slate-400">{p.width}x{p.height}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Word Input */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Word List (comma or newline separated)
          </label>
          <textarea
            value={wordsInput}
            onChange={e => setWordsInput(e.target.value)}
            rows={4}
            className="w-full text-xs font-mono p-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            placeholder="EARTH, MARS, JUPITER..."
          />
          <p className="text-[11px] text-slate-400 mt-1">
            {wordList.length} valid words detected (minimum 2 letters each).
          </p>
        </div>

        {/* Dimensions */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
              <span>Width: {width}</span>
            </div>
            <input
              type="range"
              min={10}
              max={22}
              value={width}
              onChange={e => setWidth(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
            />
          </div>
          <div>
            <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
              <span>Height: {height}</span>
            </div>
            <input
              type="range"
              min={10}
              max={22}
              value={height}
              onChange={e => setHeight(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
            />
          </div>
        </div>

        {/* Direction Toggles */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-2">
            Allowed Word Directions
          </label>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={allowHorizontal}
                onChange={e => setAllowHorizontal(e.target.checked)}
                className="rounded text-indigo-600 focus:ring-indigo-500"
              />
              <span>Horizontal (→)</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={allowVertical}
                onChange={e => setAllowVertical(e.target.checked)}
                className="rounded text-indigo-600 focus:ring-indigo-500"
              />
              <span>Vertical (↓)</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={allowDiagonal}
                onChange={e => setAllowDiagonal(e.target.checked)}
                className="rounded text-indigo-600 focus:ring-indigo-500"
              />
              <span>Diagonal (↘ ↗)</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={allowReverse}
                onChange={e => setAllowReverse(e.target.checked)}
                className="rounded text-indigo-600 focus:ring-indigo-500"
              />
              <span>Backwards (←)</span>
            </label>
          </div>
        </div>
      </div>

      {/* Printable Area (Paper layout) */}
      <div className="lg:col-span-8 flex flex-col items-center">
        {/* Page 1: Main Worksheet */}
        <div className="worksheet-paper">
          <WorksheetHeader settings={headerSettings} isAnswerKey={showAnswerKey} />
          {renderGrid(showAnswerKey)}
          {renderWordBank()}
          <WorksheetFooter />
        </div>

        {/* Page 2: Answer Key (if separate page print enabled) */}
        {printSeparateKey && !showAnswerKey && (
          <div className="worksheet-paper mt-8 page-break">
            <WorksheetHeader settings={headerSettings} isAnswerKey={true} />
            {renderGrid(true)}
            {renderWordBank()}
            <WorksheetFooter />
          </div>
        )}
      </div>
    </div>
  );
};
