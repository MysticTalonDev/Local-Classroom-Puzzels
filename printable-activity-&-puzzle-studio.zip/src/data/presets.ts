export const PRESETS = {
  'word-search': [
    {
      name: 'Solar System & Space',
      description: '12 planetary and celestial terms',
      title: 'Solar System Word Search',
      subtitle: 'Find all 12 words hidden in the cosmic grid. Look horizontally, vertically, and diagonally!',
      width: 14,
      height: 14,
      allowHorizontal: true,
      allowVertical: true,
      allowDiagonal: true,
      allowReverse: false,
      words: [
        'MERCURY', 'VENUS', 'EARTH', 'MARS', 'JUPITER', 'SATURN',
        'URANUS', 'NEPTUNE', 'COMET', 'GALAXY', 'ASTEROID', 'ORBIT'
      ]
    },
    {
      name: 'Ocean Wonders',
      description: 'Marine creatures and ocean features',
      title: 'Ocean Life Word Search',
      subtitle: 'Dive deep and discover 12 sea animals hidden in the ocean depths!',
      width: 15,
      height: 15,
      allowHorizontal: true,
      allowVertical: true,
      allowDiagonal: true,
      allowReverse: true,
      words: [
        'DOLPHIN', 'OCTOPUS', 'JELLYFISH', 'SEAHORSE', 'STARFISH',
        'LOBSTER', 'STINGRAY', 'ANEMONE', 'TURTLE', 'CORAL', 'WHALE', 'SHARK'
      ]
    },
    {
      name: 'Classroom Science & STEM',
      description: 'Essential science inquiry vocabulary',
      title: 'Science & Discovery Word Search',
      subtitle: 'Locate all the fundamental science keywords in the grid.',
      width: 15,
      height: 15,
      allowHorizontal: true,
      allowVertical: true,
      allowDiagonal: true,
      allowReverse: false,
      words: [
        'HYPOTHESIS', 'EXPERIMENT', 'GRAVITY', 'ENERGY', 'MOLECULE',
        'ECOSYSTEM', 'PHOTOSYNTHESIS', 'ELECTRON', 'CLIMATE', 'OBSERVE'
      ]
    }
  ],

  'crossword': [
    {
      name: 'World Geography & Earth',
      title: 'World Geography Crossword',
      subtitle: 'Read each clue carefully to complete the geographic puzzle.',
      pairs: [
        { word: 'PACIFIC', clue: 'The largest ocean on planet Earth' },
        { word: 'SAHARA', clue: 'Famous sprawling desert in northern Africa' },
        { word: 'AMAZON', clue: 'Massive South American river and rainforest basin' },
        { word: 'EVEREST', clue: 'The tallest mountain peak above sea level' },
        { word: 'EQUATOR', clue: 'Imaginary line dividing the Northern and Southern Hemispheres' },
        { word: 'PARIS', clue: 'The City of Light and capital of France' },
        { word: 'ISLAND', clue: 'A body of land completely surrounded by water' },
        { word: 'CANYON', clue: 'A deep gorge typically carved by a flowing river' }
      ]
    },
    {
      name: 'Animal Kingdom',
      title: 'Animal Kingdom Crossword',
      subtitle: 'Test your wildlife knowledge with these creature clues.',
      pairs: [
        { word: 'CHEETAH', clue: 'The fastest land mammal on Earth' },
        { word: 'KANGAROO', clue: 'Australian marsupial that carries joeys in a pouch' },
        { word: 'PENGUIN', clue: 'Flightless seabird that thrives in freezing polar ice' },
        { word: 'CHAMELEON', clue: 'Lizard known for changing skin color and independently moving eyes' },
        { word: 'ELEPHANT', clue: 'Largest land animal with ivory tusks and a dexterous trunk' },
        { word: 'GIRAFFE', clue: 'Tall African animal with a spotted coat and long neck' },
        { word: 'OCTOPUS', clue: 'Eight-armed intelligent cephalopod with three hearts' }
      ]
    }
  ],

  'bingo': [
    {
      name: 'Classroom Math Terms',
      title: 'Math Vocabulary Bingo',
      subtitle: 'Mark off the mathematical term as your teacher announces the definition!',
      cardCount: 6,
      freeSpaceText: 'FREE',
      items: [
        'ADDITION', 'SUBTRACTION', 'FRACTION', 'DECIMAL', 'PERCENT',
        'PERIMETER', 'AREA', 'VOLUME', 'DIAMETER', 'RADIUS',
        'POLYGON', 'TRIANGLE', 'EQUILATERAL', 'ISOSCELES', 'PARALLEL',
        'PERPENDICULAR', 'HYPOTENUSE', 'INTEGER', 'EXPONENT', 'VARIABLE',
        'EQUATION', 'AVERAGE', 'MEDIAN', 'PROBABILITY', 'RATIO', 'SYMMETRY'
      ]
    },
    {
      name: 'U.S. State Capitals',
      title: 'State Capitals Bingo',
      subtitle: 'Listen for the state name and find its capital city on your card!',
      cardCount: 6,
      freeSpaceText: 'STAR',
      items: [
        'AUSTIN', 'SACRAMENTO', 'ALBANY', 'DENVER', 'BOSTON',
        'ATLANTA', 'NASHVILLE', 'PHOENIX', 'HONOLULU', 'JUNEAU',
        'TALLAHASSEE', 'SPRINGFIELD', 'INDIANAPOLIS', 'LANSING', 'COLUMBUS',
        'SALEM', 'OLYMPIA', 'SALT LAKE CITY', 'RICHMOND', 'RALEIGH',
        'MADISON', 'DES MOINES', 'BOISE', 'SANTA FE', 'HELENA', 'PIERRE'
      ]
    }
  ],

  'word-scramble': [
    {
      name: 'Solar System & Astronomy',
      title: 'Space Scramble Challenge',
      subtitle: 'Unscramble the letters to reveal celestial objects and write the answers in the spaces.',
      items: [
        { word: 'GALAXY', clue: 'A vast system of billions of stars, gas, and dust' },
        { word: 'TELESCOPE', clue: 'Optical instrument used to observe distant planets' },
        { word: 'ASTEROID', clue: 'Rocky object orbiting the sun, mostly between Mars and Jupiter' },
        { word: 'SATELLITE', clue: 'An artificial body placed in orbit round the earth or moon' },
        { word: 'ECLIPSE', clue: 'An obscuring of light from one celestial body by another' },
        { word: 'CONSTELLATION', clue: 'A recognizable pattern of stars forming a mythological figure' },
        { word: 'METEOR', clue: 'A streak of light produced when a space rock enters Earth’s atmosphere' },
        { word: 'GRAVITY', clue: 'The universal force that attracts objects toward each other' }
      ]
    },
    {
      name: 'Rainforest Ecosystem',
      title: 'Rainforest Wildlife Scramble',
      subtitle: 'Rearrange the letters to name these creatures of the tropical jungle.',
      items: [
        { word: 'JAGUAR', clue: 'Spotted apex predator of Central and South America' },
        { word: 'TOUCAN', clue: 'Vibrant bird famous for its massive colorful bill' },
        { word: 'SLOTH', clue: 'Slow-moving tree dweller that hangs upside down' },
        { word: 'ANACONDA', clue: 'One of the heaviest and longest snakes in the world' },
        { word: 'PIRANHA', clue: 'Sharp-toothed freshwater fish native to South American rivers' },
        { word: 'ORANGUTAN', clue: 'Intelligent red-haired ape native to Indonesian forests' },
        { word: 'CANOPY', clue: 'The dense leafy roof formed by the tops of the trees' }
      ]
    }
  ],

  'cryptogram': [
    {
      name: 'Albert Einstein on Curiosity',
      title: 'Famous Thinkers Cryptogram',
      subtitle: 'Use your code-breaking skills and letter frequency hints to decipher the hidden quote.',
      quote: 'THE IMPORTANT THING IS NOT TO STOP QUESTIONING. CURIOSITY HAS ITS OWN REASON FOR EXISTING.',
      author: 'Albert Einstein',
      hintsCount: 2
    },
    {
      name: 'Helen Keller on Optimism',
      title: 'Inspirational Wisdom Cryptogram',
      subtitle: 'Crack the cipher code by matching encrypted letters with their true alphabet values.',
      quote: 'OPTIMISM IS THE FAITH THAT LEADS TO ACHIEVEMENT. NOTHING CAN BE DONE WITHOUT HOPE AND CONFIDENCE.',
      author: 'Helen Keller',
      hintsCount: 2
    },
    {
      name: 'Nelson Mandela on Learning',
      title: 'Historic Quotes Cryptogram',
      subtitle: 'Decode this famous observation on education and positive transformation.',
      quote: 'EDUCATION IS THE MOST POWERFUL WEAPON WHICH YOU CAN USE TO CHANGE THE WORLD.',
      author: 'Nelson Mandela',
      hintsCount: 2
    }
  ],

  'maze': [
    {
      name: 'Classroom Quick Maze (12x12)',
      title: 'The Labyrinth Challenge',
      subtitle: 'Guide your pencil from the top-left Entrance (▼) to the bottom-right Exit (★)!',
      cols: 12,
      rows: 12
    },
    {
      name: 'Standard Puzzle Maze (18x18)',
      title: 'The Great Maze Adventure',
      subtitle: 'Navigate twisting corridors and dead ends to reach the goal.',
      cols: 18,
      rows: 18
    },
    {
      name: 'Expert Mega Maze (26x26)',
      title: 'Ultimate Brain-Teaser Maze',
      subtitle: 'A high-density winding labyrinth for advanced puzzle solvers.',
      cols: 26,
      rows: 26
    }
  ],

  'matching': [
    {
      name: 'Famous Inventions & Inventors',
      title: 'Inventions Matching Worksheet',
      subtitle: 'Match each historic innovation in Column A with its legendary creator in Column B.',
      pairs: [
        { left: 'Telephone', right: 'Alexander Graham Bell' },
        { left: 'Light Bulb & Phonograph', right: 'Thomas Edison' },
        { left: 'Alternating Current (AC)', right: 'Nikola Tesla' },
        { left: 'Airplane Motor Flight', right: 'Wright Brothers' },
        { left: 'Penicillin Antibiotic', right: 'Alexander Fleming' },
        { left: 'Printing Press', right: 'Johannes Gutenberg' },
        { left: 'Steam Engine Improvement', right: 'James Watt' },
        { left: 'World Wide Web', right: 'Tim Berners-Lee' }
      ]
    },
    {
      name: 'World Capitals',
      title: 'World Capitals Connection',
      subtitle: 'Write the correct capital letter in the box and draw a line connecting each nation to its capital.',
      pairs: [
        { left: 'Japan', right: 'Tokyo' },
        { left: 'Australia', right: 'Canberra' },
        { left: 'Egypt', right: 'Cairo' },
        { left: 'Brazil', right: 'Brasília' },
        { left: 'Canada', right: 'Ottawa' },
        { left: 'Italy', right: 'Rome' },
        { left: 'South Korea', right: 'Seoul' },
        { left: 'Kenya', right: 'Nairobi' }
      ]
    },
    {
      name: 'English to Spanish Basics',
      title: 'Spanish Vocabulary Matching',
      subtitle: 'Match the English vocabulary words to their Spanish equivalents.',
      pairs: [
        { left: 'Friend', right: 'Amigo' },
        { left: 'Book', right: 'Libro' },
        { left: 'Sun', right: 'Sol' },
        { left: 'Water', right: 'Agua' },
        { left: 'House', right: 'Casa' },
        { left: 'School', right: 'Escuela' },
        { left: 'Happy', right: 'Feliz' },
        { left: 'Morning', right: 'Mañana' }
      ]
    }
  ],

  'sudoku': [
    {
      name: 'Beginner Easy Sudoku',
      title: 'Classroom Sudoku (Easy)',
      subtitle: 'Fill in the grid so every row, column, and 3x3 box contains the numbers 1 through 9.',
      difficulty: 'easy' as const
    },
    {
      name: 'Standard Medium Sudoku',
      title: 'Daily Sudoku Challenge (Medium)',
      subtitle: 'Apply logic and deduction to complete all 81 squares without repetition.',
      difficulty: 'medium' as const
    },
    {
      name: 'Brain Buster Hard Sudoku',
      title: 'Expert Logic Sudoku (Hard)',
      subtitle: 'A challenging puzzle designed to test advanced numerical elimination techniques.',
      difficulty: 'hard' as const
    }
  ],

  'word-ladder': [
    {
      name: 'COLD to WARM',
      title: 'Word Ladder: Temperature Shift',
      subtitle: 'Change one letter at a time to transform COLD into WARM. Each step must form a valid dictionary word!',
      start: 'COLD',
      end: 'WARM'
    },
    {
      name: 'LEAD to GOLD',
      title: 'Word Ladder: The Alchemist Challenge',
      subtitle: 'Transform LEAD into pure GOLD by altering a single letter on each rung of the ladder.',
      start: 'LEAD',
      end: 'GOLD'
    },
    {
      name: 'CAT to DOG',
      title: 'Word Ladder: Pet Swap',
      subtitle: 'Turn CAT into DOG in 3 easy steps.',
      start: 'CAT',
      end: 'DOG'
    },
    {
      name: 'HEAD to TAIL',
      title: 'Word Ladder: Head to Tail',
      subtitle: 'Connect HEAD to TAIL one letter step at a time.',
      start: 'HEAD',
      end: 'TAIL'
    },
    {
      name: 'WHEAT to BREAD',
      title: 'Word Ladder: From Field to Table',
      subtitle: 'Turn five-letter WHEAT into delicious BREAD step by step.',
      start: 'WHEAT',
      end: 'BREAD'
    }
  ],

  'fill-blank': [
    {
      name: 'The Chaotic Science Fair',
      title: 'The Great School Science Fair Disaster',
      subtitle: 'Player 1: Ask your partner for the requested words below without showing them the story. Once filled, read Part 2 out loud!',
      story: 'Yesterday was our annual school science fair. My best friend [person\'s name] and I built a machine called the [adjective] Inventions-O-Matic. When Principal [last name] pressed the [color] button, it let out a loud [sound effect]! Suddenly, hot [liquid] started spraying all over the [noun]. A giant [animal] leaped onto the stage and began to [verb] wildly while throwing [plural noun] into the crowd! Everyone screamed with [emotion], but the judges awarded us [number] gold medals for the most [adjective] presentation in school history.'
    },
    {
      name: 'A Day at the Zany Zoo',
      title: 'Wild Safari Adventures',
      subtitle: 'Fill in the blanks with hilarious descriptors, then unveil your one-of-a-kind safari adventure story!',
      story: 'Today our class took a field trip to the [adjective] Zoo. The very first exhibit we saw had three [adjective] [plural animal] eating [food item]. One of them looked directly at [friend\'s name] and began to [verb] like a [profession]. Our tour guide, Ranger [funny name], told us never to feed them [plural noun] or they would [verb] all day long. At lunchtime, a sneaky [animal] stole my [noun] and flew into a tall [type of plant]. It was the most [adjective] school trip ever!'
    },
    {
      name: 'Astronaut Space Lunch',
      title: 'Zero-Gravity Cafeteria',
      subtitle: 'Write in your mystery words first, then read the cosmic lunchroom incident aloud!',
      story: 'Living on the International Space Station is really [adjective]. Eating lunch in zero gravity is especially tricky. Today we had dehydrated [food item] and tubes of [liquid]. When Commander [name] opened a bag of [plural noun], they began floating toward the [room in a house]! I had to use a [utensil or tool] to [verb] them back into my mouth. Suddenly, the alarm began to [sound], because an alien [noun] was tapping on the spacecraft window asking for a taste of our [adjective] dessert!'
    }
  ]
};
