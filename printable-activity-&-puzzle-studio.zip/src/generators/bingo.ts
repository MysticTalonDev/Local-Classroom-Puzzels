export interface BingoCard {
  id: number;
  grid: string[][]; // 5x5
}

export interface BingoOptions {
  items: string[];
  cardCount: number;
  freeSpaceText: string;
  headerLetters: string[]; // ['B', 'I', 'N', 'G', 'O']
}

export interface BingoResult {
  cards: BingoCard[];
  callerItems: string[];
  totalUniqueWords: number;
}

export function generateBingoCards(options: BingoOptions): BingoResult {
  const cleanItems = Array.from(
    new Set(
      options.items
        .map(i => i.trim())
        .filter(i => i.length > 0)
    )
  );

  const callerItems = [...cleanItems].sort((a, b) => a.localeCompare(b));
  const cardCount = Math.min(Math.max(1, options.cardCount), 50);
  const freeText = options.freeSpaceText.trim() || 'FREE';

  // If fewer than 24 items, duplicate items to fill at least 24 slots
  let pool = [...cleanItems];
  if (pool.length < 24) {
    while (pool.length < 24 && pool.length > 0) {
      pool = [...pool, ...cleanItems];
    }
  }

  const cards: BingoCard[] = [];

  for (let c = 1; c <= cardCount; c++) {
    // Fisher-Yates shuffle of pool
    const shuffled = [...pool];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }

    const grid: string[][] = [];
    let itemIdx = 0;

    for (let r = 0; r < 5; r++) {
      const row: string[] = [];
      for (let col = 0; col < 5; col++) {
        if (r === 2 && col === 2) {
          row.push(freeText);
        } else {
          row.push(shuffled[itemIdx % shuffled.length]);
          itemIdx++;
        }
      }
      grid.push(row);
    }

    cards.push({
      id: c,
      grid,
    });
  }

  return {
    cards,
    callerItems,
    totalUniqueWords: cleanItems.length,
  };
}
