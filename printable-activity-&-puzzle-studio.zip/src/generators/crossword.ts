export interface WordCluePair {
  word: string;
  clue: string;
}

export interface PlacedCrosswordWord {
  word: string;
  clue: string;
  row: number;
  col: number;
  direction: 'across' | 'down';
  number?: number;
}

export interface CrosswordCell {
  char: string;
  number?: number;
  isBlocked: boolean;
}

export interface CrosswordClue {
  number: number;
  clue: string;
  answer: string;
}

export interface CrosswordResult {
  grid: CrosswordCell[][];
  acrossClues: CrosswordClue[];
  downClues: CrosswordClue[];
  unplaced: WordCluePair[];
  rows: number;
  cols: number;
}

export function generateCrossword(pairs: WordCluePair[]): CrosswordResult {
  // Filter valid entries
  const cleanPairs = pairs
    .map(p => ({
      word: p.word.trim().toUpperCase().replace(/[^A-Z]/g, ''),
      clue: p.clue.trim() || 'No clue provided',
    }))
    .filter(p => p.word.length >= 2);

  if (cleanPairs.length === 0) {
    return {
      grid: [],
      acrossClues: [],
      downClues: [],
      unplaced: [],
      rows: 0,
      cols: 0,
    };
  }

  // Work on a large virtual plane centered at (0, 0)
  // map key: "row,col" -> char
  let board = new Map<string, string>();
  const placedWords: PlacedCrosswordWord[] = [];
  const unplaced: WordCluePair[] = [];

  // Sort longest words first
  const sortedPairs = [...cleanPairs].sort((a, b) => b.word.length - a.word.length);

  // Place first word horizontally starting at (0, 0)
  const first = sortedPairs[0];
  for (let i = 0; i < first.word.length; i++) {
    board.set(`0,${i}`, first.word[i]);
  }
  placedWords.push({
    word: first.word,
    clue: first.clue,
    row: 0,
    col: 0,
    direction: 'across',
  });

  // Try placing the remaining words
  for (let pIdx = 1; pIdx < sortedPairs.length; pIdx++) {
    const item = sortedPairs[pIdx];
    const word = item.word;

    let bestPlacement: { row: number; col: number; direction: 'across' | 'down'; intersections: number } | null = null;
    let maxIntersections = 0;

    // Check potential intersections against all already placed words
    for (const placed of placedWords) {
      const targetDir: 'across' | 'down' = placed.direction === 'across' ? 'down' : 'across';

      for (let i = 0; i < word.length; i++) {
        const char = word[i];

        // Search for char in the placed word
        for (let j = 0; j < placed.word.length; j++) {
          if (placed.word[j] === char) {
            // Calculate candidate start coordinates for this word
            let startRow: number;
            let startCol: number;

            if (targetDir === 'down') {
              // placed was across
              startRow = placed.row - i;
              startCol = placed.col + j;
            } else {
              // placed was down
              startRow = placed.row + j;
              startCol = placed.col - i;
            }

            // Validate candidate placement
            if (canPlaceWord(word, startRow, startCol, targetDir, board)) {
              // Count intersections
              const intersections = countIntersections(word, startRow, startCol, targetDir, board);
              if (!bestPlacement || intersections > maxIntersections) {
                maxIntersections = intersections;
                bestPlacement = { row: startRow, col: startCol, direction: targetDir, intersections };
              }
            }
          }
        }
      }
    }

    if (bestPlacement) {
      // Place word on board
      const { row, col, direction } = bestPlacement;
      for (let i = 0; i < word.length; i++) {
        const r = direction === 'across' ? row : row + i;
        const c = direction === 'across' ? col + i : col;
        board.set(`${r},${c}`, word[i]);
      }
      placedWords.push({
        word,
        clue: item.clue,
        row,
        col,
        direction,
      });
    } else {
      unplaced.push(item);
    }
  }

  // Find bounding box
  let minRow = Infinity;
  let maxRow = -Infinity;
  let minCol = Infinity;
  let maxCol = -Infinity;

  board.forEach((_, key) => {
    const [r, c] = key.split(',').map(Number);
    if (r < minRow) minRow = r;
    if (r > maxRow) maxRow = r;
    if (c < minCol) minCol = c;
    if (c > maxCol) maxCol = c;
  });

  const rows = maxRow - minRow + 1;
  const cols = maxCol - minCol + 1;

  // Initialize output grid
  const grid: CrosswordCell[][] = Array.from({ length: rows }, () =>
    Array.from({ length: cols }, () => ({
      char: '',
      isBlocked: true,
    }))
  );

  // Fill in active letters
  board.forEach((char, key) => {
    const [r, c] = key.split(',').map(Number);
    grid[r - minRow][c - minCol] = {
      char,
      isBlocked: false,
    };
  });

  // Adjust placed words coordinates relative to minRow, minCol
  for (const pw of placedWords) {
    pw.row -= minRow;
    pw.col -= minCol;
  }

  // Assign clue numbers scanning row by row
  let currentNum = 1;
  const acrossClues: CrosswordClue[] = [];
  const downClues: CrosswordClue[] = [];

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (grid[r][c].isBlocked) continue;

      let isAcrossStart = false;
      let isDownStart = false;

      // Check if starts an Across word (at least 2 letters, left is blocked or boundary, right is letter)
      if ((c === 0 || grid[r][c - 1].isBlocked) && c + 1 < cols && !grid[r][c + 1].isBlocked) {
        isAcrossStart = true;
      }

      // Check if starts a Down word (at least 2 letters, above is blocked or boundary, below is letter)
      if ((r === 0 || grid[r - 1][c].isBlocked) && r + 1 < rows && !grid[r + 1][c].isBlocked) {
        isDownStart = true;
      }

      if (isAcrossStart || isDownStart) {
        grid[r][c].number = currentNum;

        if (isAcrossStart) {
          const match = placedWords.find(pw => pw.direction === 'across' && pw.row === r && pw.col === c);
          if (match) {
            match.number = currentNum;
            acrossClues.push({
              number: currentNum,
              clue: match.clue,
              answer: match.word,
            });
          }
        }

        if (isDownStart) {
          const match = placedWords.find(pw => pw.direction === 'down' && pw.row === r && pw.col === c);
          if (match) {
            match.number = currentNum;
            downClues.push({
              number: currentNum,
              clue: match.clue,
              answer: match.word,
            });
          }
        }

        currentNum++;
      }
    }
  }

  acrossClues.sort((a, b) => a.number - b.number);
  downClues.sort((a, b) => a.number - b.number);

  return {
    grid,
    acrossClues,
    downClues,
    unplaced,
    rows,
    cols,
  };
}

function canPlaceWord(
  word: string,
  startRow: number,
  startCol: number,
  direction: 'across' | 'down',
  board: Map<string, string>
): boolean {
  // Check boundary immediate prefix cell (must not touch another word)
  const prevR = direction === 'across' ? startRow : startRow - 1;
  const prevC = direction === 'across' ? startCol - 1 : startCol;
  if (board.has(`${prevR},${prevC}`)) return false;

  // Check boundary immediate suffix cell
  const nextR = direction === 'across' ? startRow : startRow + word.length;
  const nextC = direction === 'across' ? startCol + word.length : startCol;
  if (board.has(`${nextR},${nextC}`)) return false;

  let intersectionCount = 0;

  for (let i = 0; i < word.length; i++) {
    const r = direction === 'across' ? startRow : startRow + i;
    const c = direction === 'across' ? startCol + i : startCol;
    const existing = board.get(`${r},${c}`);

    if (existing !== undefined) {
      if (existing !== word[i]) {
        return false; // Collision with non-matching letter
      }
      intersectionCount++;
    } else {
      // If cell is empty, check parallel neighbors (prevent accidental adjacent parallel runs)
      if (direction === 'across') {
        if (board.has(`${r - 1},${c}`) || board.has(`${r + 1},${c}`)) {
          return false;
        }
      } else {
        if (board.has(`${r},${c - 1}`) || board.has(`${r},${c + 1}`)) {
          return false;
        }
      }
    }
  }

  return intersectionCount > 0;
}

function countIntersections(
  word: string,
  startRow: number,
  startCol: number,
  direction: 'across' | 'down',
  board: Map<string, string>
): number {
  let count = 0;
  for (let i = 0; i < word.length; i++) {
    const r = direction === 'across' ? startRow : startRow + i;
    const c = direction === 'across' ? startCol + i : startCol;
    if (board.has(`${r},${c}`)) {
      count++;
    }
  }
  return count;
}
