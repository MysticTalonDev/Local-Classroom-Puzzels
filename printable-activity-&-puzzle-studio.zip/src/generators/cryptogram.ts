export interface CryptogramOptions {
  quote: string;
  author?: string;
  revealedHintsCount?: number; // e.g. 0, 1, 2
}

export interface CryptogramLetterBox {
  originalChar: string;
  cipherChar: string;
  isLetter: boolean;
  isRevealedHint?: boolean;
}

export interface CryptogramWord {
  boxes: CryptogramLetterBox[];
}

export interface CryptogramResult {
  originalQuote: string;
  author?: string;
  cipherQuote: string;
  words: CryptogramWord[];
  cipherMap: Record<string, string>; // Plain -> Cipher
  reverseCipherMap: Record<string, string>; // Cipher -> Plain
  frequencyMap: Record<string, number>; // Cipher Letter -> Count
  hints: { plain: string; cipher: string }[];
}

export function generateCryptogram(options: CryptogramOptions): CryptogramResult {
  const quote = options.quote.trim().toUpperCase();
  const author = options.author?.trim();
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

  // Generate derangement (no letter maps to itself)
  let shuffled = [...alphabet];
  let isDerangement = false;
  let safety = 0;

  while (!isDerangement && safety < 1000) {
    safety++;
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    isDerangement = alphabet.every((ch, idx) => ch !== shuffled[idx]);
  }

  const cipherMap: Record<string, string> = {};
  const reverseCipherMap: Record<string, string> = {};

  alphabet.forEach((plain, idx) => {
    const cipher = shuffled[idx];
    cipherMap[plain] = cipher;
    reverseCipherMap[cipher] = plain;
  });

  // Calculate frequency counts for cipher letters used in the quote
  const frequencyMap: Record<string, number> = {};
  alphabet.forEach(ch => {
    frequencyMap[ch] = 0;
  });

  let cipherQuote = '';
  for (const ch of quote) {
    if (/[A-Z]/.test(ch)) {
      const c = cipherMap[ch];
      cipherQuote += c;
      frequencyMap[c] = (frequencyMap[c] || 0) + 1;
    } else {
      cipherQuote += ch;
    }
  }

  // Determine hints to reveal
  const revealedHintsCount = options.revealedHintsCount ?? 1;
  // Get all unique letters present in quote
  const presentLetters = Array.from(new Set(quote.split('').filter(c => /[A-Z]/.test(c))));
  const hints: { plain: string; cipher: string }[] = [];

  // Pick common letters like 'E', 'T', 'A' if present, or random
  const preferredLetters = ['E', 'T', 'A', 'O', 'I', 'N', 'S', 'H', 'R'];
  for (const pl of preferredLetters) {
    if (hints.length >= revealedHintsCount) break;
    if (presentLetters.includes(pl)) {
      hints.push({ plain: pl, cipher: cipherMap[pl] });
    }
  }

  // Break quote into words and lines for nice worksheet formatting
  const rawWords = quote.split(' ');
  const words: CryptogramWord[] = rawWords.map(rawWord => {
    const boxes: CryptogramLetterBox[] = [];
    for (const char of rawWord) {
      const isLetter = /[A-Z]/.test(char);
      const cipherChar = isLetter ? cipherMap[char] : char;
      const isRevealedHint = hints.some(h => h.plain === char);
      boxes.push({
        originalChar: char,
        cipherChar,
        isLetter,
        isRevealedHint,
      });
    }
    return { boxes };
  });

  return {
    originalQuote: quote,
    author,
    cipherQuote,
    words,
    cipherMap,
    reverseCipherMap,
    frequencyMap,
    hints,
  };
}
