export interface StoryPrompt {
  id: number;
  placeholderText: string; // e.g. "adjective", "silly animal"
  userWord?: string;
}

export interface StorySegment {
  type: 'text' | 'blank';
  content: string;
  promptId?: number;
  label?: string;
}

export interface FillInTheBlankResult {
  prompts: StoryPrompt[];
  segments: StorySegment[];
  rawTemplate: string;
  storyTitle: string;
}

export function generateFillInTheBlank(
  rawText: string,
  customTitle?: string
): FillInTheBlankResult {
  const text = rawText.trim();
  const prompts: StoryPrompt[] = [];
  const segments: StorySegment[] = [];

  // Match [placeholder] or <placeholder>
  const regex = /\[([^\]]+)\]|<([^>]+)>/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;
  let promptCounter = 1;

  while ((match = regex.exec(text)) !== null) {
    // Add text preceding the match
    if (match.index > lastIndex) {
      segments.push({
        type: 'text',
        content: text.substring(lastIndex, match.index),
      });
    }

    const placeholder = (match[1] || match[2]).trim();
    const promptId = promptCounter++;

    prompts.push({
      id: promptId,
      placeholderText: placeholder,
    });

    segments.push({
      type: 'blank',
      content: '',
      promptId,
      label: placeholder,
    });

    lastIndex = regex.lastIndex;
  }

  // Add trailing text
  if (lastIndex < text.length) {
    segments.push({
      type: 'text',
      content: text.substring(lastIndex),
    });
  }

  return {
    prompts,
    segments,
    rawTemplate: text,
    storyTitle: customTitle?.trim() || 'Fill-in-the-Blank Story',
  };
}
