export interface MatchingPair {
  left: string;
  right: string;
}

export interface MatchingItemA {
  index: number; // 1, 2, 3...
  text: string;
  correctLetter: string; // 'A', 'B', 'C'...
  correctRightText: string;
}

export interface MatchingItemB {
  letter: string; // 'A', 'B', 'C'...
  text: string;
}

export interface MatchingResult {
  columnA: MatchingItemA[];
  columnB: MatchingItemB[];
  pairsCount: number;
}

export function generateMatchingWorksheet(
  pairs: MatchingPair[],
  options?: { shuffleLeft?: boolean }
): MatchingResult {
  const cleanPairs = pairs
    .map(p => ({ left: p.left.trim(), right: p.right.trim() }))
    .filter(p => p.left.length > 0 && p.right.length > 0);

  if (cleanPairs.length === 0) {
    return { columnA: [], columnB: [], pairsCount: 0 };
  }

  // Optionally shuffle column A or preserve original order
  let listA = [...cleanPairs];
  if (options?.shuffleLeft) {
    for (let i = listA.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [listA[i], listA[j]] = [listA[j], listA[i]];
    }
  }

  // Shuffle column B independently
  const listB = [...cleanPairs];
  for (let i = listB.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [listB[i], listB[j]] = [listB[j], listB[i]];
  }

  // Assign letters A, B, C... to Column B
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const columnB: MatchingItemB[] = listB.map((item, idx) => {
    const letter = idx < 26 ? alphabet[idx] : `${alphabet[Math.floor(idx / 26) - 1]}${alphabet[idx % 26]}`;
    return {
      letter,
      text: item.right,
    };
  });

  // Map each item in Column A to its corresponding letter in Column B
  const columnA: MatchingItemA[] = listA.map((item, idx) => {
    const matchedB = columnB.find(b => b.text === item.right);
    const correctLetter = matchedB ? matchedB.letter : '?';
    return {
      index: idx + 1,
      text: item.left,
      correctLetter,
      correctRightText: item.right,
    };
  });

  return {
    columnA,
    columnB,
    pairsCount: columnA.length,
  };
}
