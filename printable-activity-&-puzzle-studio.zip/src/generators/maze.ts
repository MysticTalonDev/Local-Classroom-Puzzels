export interface MazeCell {
  row: number;
  col: number;
  top: boolean;
  right: boolean;
  bottom: boolean;
  left: boolean;
  visited: boolean;
}

export interface MazeOptions {
  cols: number; // width in cells (e.g. 10 to 30)
  rows: number; // height in cells (e.g. 10 to 30)
}

export interface MazeResult {
  cols: number;
  rows: number;
  grid: MazeCell[][];
  start: { row: number; col: number };
  end: { row: number; col: number };
  solutionPath: { row: number; col: number }[];
}

export function generateMaze(options: MazeOptions): MazeResult {
  const cols = Math.max(5, Math.min(40, options.cols));
  const rows = Math.max(5, Math.min(40, options.rows));

  // Initialize grid with all walls intact
  const grid: MazeCell[][] = Array.from({ length: rows }, (_, r) =>
    Array.from({ length: cols }, (_, c) => ({
      row: r,
      col: c,
      top: true,
      right: true,
      bottom: true,
      left: true,
      visited: false,
    }))
  );

  // Recursive Backtracking algorithm using explicit stack
  const stack: { row: number; col: number }[] = [];
  const startRow = 0;
  const startCol = 0;
  grid[startRow][startCol].visited = true;
  stack.push({ row: startRow, col: startCol });

  while (stack.length > 0) {
    const current = stack[stack.length - 1];
    const neighbors = getUnvisitedNeighbors(current.row, current.col, rows, cols, grid);

    if (neighbors.length > 0) {
      // Pick random neighbor
      const next = neighbors[Math.floor(Math.random() * neighbors.length)];
      // Carve walls between current and next
      removeWalls(grid[current.row][current.col], grid[next.row][next.col], next.direction);
      grid[next.row][next.col].visited = true;
      stack.push({ row: next.row, col: next.col });
    } else {
      stack.pop();
    }
  }

  // Define start and end
  const start = { row: 0, col: 0 };
  const end = { row: rows - 1, col: cols - 1 };

  // Carve start and end entrances on perimeter
  grid[start.row][start.col].top = false; // entrance at top
  grid[end.row][end.col].bottom = false; // exit at bottom

  // Solve maze using BFS to get shortest path for solution key
  const solutionPath = solveMazeBFS(grid, start, end, rows, cols);

  return {
    cols,
    rows,
    grid,
    start,
    end,
    solutionPath,
  };
}

interface Neighbor {
  row: number;
  col: number;
  direction: 'top' | 'right' | 'bottom' | 'left';
}

function getUnvisitedNeighbors(
  r: number,
  c: number,
  rows: number,
  cols: number,
  grid: MazeCell[][]
): Neighbor[] {
  const list: Neighbor[] = [];
  if (r > 0 && !grid[r - 1][c].visited) list.push({ row: r - 1, col: c, direction: 'top' });
  if (c < cols - 1 && !grid[r][c + 1].visited) list.push({ row: r, col: c + 1, direction: 'right' });
  if (r < rows - 1 && !grid[r + 1][c].visited) list.push({ row: r + 1, col: c, direction: 'bottom' });
  if (c > 0 && !grid[r][c - 1].visited) list.push({ row: r, col: c - 1, direction: 'left' });
  return list;
}

function removeWalls(
  curr: MazeCell,
  next: MazeCell,
  direction: 'top' | 'right' | 'bottom' | 'left'
) {
  if (direction === 'top') {
    curr.top = false;
    next.bottom = false;
  } else if (direction === 'right') {
    curr.right = false;
    next.left = false;
  } else if (direction === 'bottom') {
    curr.bottom = false;
    next.top = false;
  } else if (direction === 'left') {
    curr.left = false;
    next.right = false;
  }
}

function solveMazeBFS(
  grid: MazeCell[][],
  start: { row: number; col: number },
  end: { row: number; col: number },
  rows: number,
  cols: number
): { row: number; col: number }[] {
  const queue: { row: number; col: number; path: { row: number; col: number }[] }[] = [
    { row: start.row, col: start.col, path: [{ row: start.row, col: start.col }] },
  ];
  const visited = new Set<string>();
  visited.add(`${start.row},${start.col}`);

  while (queue.length > 0) {
    const current = queue.shift()!;
    if (current.row === end.row && current.col === end.col) {
      return current.path;
    }

    const cell = grid[current.row][current.col];

    // Check accessible directions (walls are false)
    if (!cell.top && current.row > 0 && !visited.has(`${current.row - 1},${current.col}`)) {
      visited.add(`${current.row - 1},${current.col}`);
      queue.push({
        row: current.row - 1,
        col: current.col,
        path: [...current.path, { row: current.row - 1, col: current.col }],
      });
    }
    if (!cell.right && current.col < cols - 1 && !visited.has(`${current.row},${current.col + 1}`)) {
      visited.add(`${current.row},${current.col + 1}`);
      queue.push({
        row: current.row,
        col: current.col + 1,
        path: [...current.path, { row: current.row, col: current.col + 1 }],
      });
    }
    if (!cell.bottom && current.row < rows - 1 && !visited.has(`${current.row + 1},${current.col}`)) {
      visited.add(`${current.row + 1},${current.col}`);
      queue.push({
        row: current.row + 1,
        col: current.col,
        path: [...current.path, { row: current.row + 1, col: current.col }],
      });
    }
    if (!cell.left && current.col > 0 && !visited.has(`${current.row},${current.col - 1}`)) {
      visited.add(`${current.row},${current.col - 1}`);
      queue.push({
        row: current.row,
        col: current.col - 1,
        path: [...current.path, { row: current.row, col: current.col - 1 }],
      });
    }
  }

  return [];
}
