export type SudokuDifficulty = 'easy' | 'medium' | 'hard' | 'expert';

export interface SudokuResult {
  puzzle: (number | null)[][]; // 9x9 grid with numbers or null
  solution: number[][]; // 9x9 fully solved grid
  difficulty: SudokuDifficulty;
  cluesCount: number;
}

export function generateSudoku(difficulty: SudokuDifficulty = 'medium'): SudokuResult {
  // 1. Generate fully solved 9x9 grid
  const solution: number[][] = Array.from({ length: 9 }, () => Array(9).fill(0));
  fillGrid(solution);

  // 2. Clone solution to create puzzle
  const puzzle: (number | null)[][] = solution.map(row => [...row]);

  // Determine how many cells to remove based on difficulty
  // Total cells = 81
  let targetClues: number;
  switch (difficulty) {
    case 'easy':
      targetClues = 40; // removes 41
      break;
    case 'medium':
      targetClues = 32; // removes 49
      break;
    case 'hard':
      targetClues = 26; // removes 55
      break;
    case 'expert':
      targetClues = 22; // removes 59
      break;
    default:
      targetClues = 32;
  }

  // Create list of all 81 cell coordinates and shuffle them
  const cellCoords: [number, number][] = [];
  for (let r = 0; r < 9; r++) {
    for (let c = 0; c < 9; c++) {
      cellCoords.push([r, c]);
    }
  }
  for (let i = cellCoords.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [cellCoords[i], cellCoords[j]] = [cellCoords[j], cellCoords[i]];
  }

  let cluesRemaining = 81;

  for (const [r, c] of cellCoords) {
    if (cluesRemaining <= targetClues) break;

    const backup = puzzle[r][c];
    puzzle[r][c] = null;

    // Check if unique solution is preserved
    const copy = puzzle.map(row => row.map(v => (v === null ? 0 : v)));
    const solutionsCount = countSolutions(copy);

    if (solutionsCount === 1) {
      cluesRemaining--;
    } else {
      // Revert if removal creates multiple solutions
      puzzle[r][c] = backup;
    }
  }

  return {
    puzzle,
    solution,
    difficulty,
    cluesCount: cluesRemaining,
  };
}

function fillGrid(grid: number[][]): boolean {
  for (let r = 0; r < 9; r++) {
    for (let c = 0; c < 9; c++) {
      if (grid[r][c] === 0) {
        const numbers = shuffleNumbers([1, 2, 3, 4, 5, 6, 7, 8, 9]);
        for (const num of numbers) {
          if (isValidPlacement(grid, r, c, num)) {
            grid[r][c] = num;
            if (fillGrid(grid)) return true;
            grid[r][c] = 0;
          }
        }
        return false;
      }
    }
  }
  return true;
}

function isValidPlacement(grid: number[][], row: number, col: number, num: number): boolean {
  // Check row and column
  for (let i = 0; i < 9; i++) {
    if (grid[row][i] === num || grid[i][col] === num) return false;
  }

  // Check 3x3 subgrid box
  const startRow = Math.floor(row / 3) * 3;
  const startCol = Math.floor(col / 3) * 3;
  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 3; c++) {
      if (grid[startRow + r][startCol + c] === num) return false;
    }
  }

  return true;
}

function shuffleNumbers(nums: number[]): number[] {
  const arr = [...nums];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function countSolutions(grid: number[][], count = { value: 0 }): number {
  for (let r = 0; r < 9; r++) {
    for (let c = 0; c < 9; c++) {
      if (grid[r][c] === 0) {
        for (let num = 1; num <= 9; num++) {
          if (isValidPlacement(grid, r, c, num)) {
            grid[r][c] = num;
            countSolutions(grid, count);
            grid[r][c] = 0;
            if (count.value >= 2) return count.value;
          }
        }
        return count.value;
      }
    }
  }
  count.value++;
  return count.value;
}
