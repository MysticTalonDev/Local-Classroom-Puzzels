import { WORD_LADDER_DICT } from '../data/wordLadderDictionary.ts';

export interface WordLadderStep {
  stepNumber: number;
  word: string; // The solution word for this step
  blankFormat: string; // e.g., "_ _ _ _"
  letterChangedIndex: number; // 0-indexed position of the letter that changed
  hint?: string;
}

export interface WordLadderResult {
  startWord: string;
  endWord: string;
  steps: WordLadderStep[];
  stepCount: number;
  success: boolean;
  errorMessage?: string;
}

export function generateWordLadder(start: string, end: string): WordLadderResult {
  const startWord = start.trim().toUpperCase().replace(/[^A-Z]/g, '');
  const endWord = end.trim().toUpperCase().replace(/[^A-Z]/g, '');

  if (!startWord || !endWord) {
    return {
      startWord,
      endWord,
      steps: [],
      stepCount: 0,
      success: false,
      errorMessage: 'Please enter both start and target words.',
    };
  }

  if (startWord.length !== endWord.length) {
    return {
      startWord,
      endWord,
      steps: [],
      stepCount: 0,
      success: false,
      errorMessage: `Both words must have the exact same length (${startWord.length} vs ${endWord.length}).`,
    };
  }

  if (startWord === endWord) {
    return {
      startWord,
      endWord,
      steps: [
        { stepNumber: 1, word: startWord, blankFormat: startWord.split('').join(' '), letterChangedIndex: -1 }
      ],
      stepCount: 1,
      success: true,
    };
  }

  // Find shortest path using BFS with WORD_LADDER_DICT
  const path = findShortestLadderBFS(startWord, endWord, WORD_LADDER_DICT);

  if (!path) {
    return {
      startWord,
      endWord,
      steps: [],
      stepCount: 0,
      success: false,
      errorMessage: `Could not find a valid 1-letter ladder path between "${startWord}" and "${endWord}" in dictionary. Try another pair or preset!`,
    };
  }

  const steps: WordLadderStep[] = path.map((word, idx) => {
    let letterChangedIndex = -1;
    if (idx > 0) {
      const prev = path[idx - 1];
      for (let i = 0; i < word.length; i++) {
        if (word[i] !== prev[i]) {
          letterChangedIndex = i;
          break;
        }
      }
    }

    // Blank format for puzzle: only first and last words shown, intermediate are blanks
    const isFirstOrLast = idx === 0 || idx === path.length - 1;
    const blankFormat = isFirstOrLast
      ? word.split('').join(' ')
      : word
          .split('')
          .map((_, i) => (i === letterChangedIndex ? '•' : '_'))
          .join(' ');

    return {
      stepNumber: idx + 1,
      word,
      blankFormat,
      letterChangedIndex,
      hint: idx > 0 && idx < path.length - 1 ? `Change letter #${letterChangedIndex + 1}` : undefined,
    };
  });

  return {
    startWord,
    endWord,
    steps,
    stepCount: steps.length,
    success: true,
  };
}

function findShortestLadderBFS(
  beginWord: string,
  endWord: string,
  wordSet: Set<string>
): string[] | null {
  // Ensure start and end are considered valid words
  const dict = new Set(wordSet);
  dict.add(beginWord);
  dict.add(endWord);

  const wordLen = beginWord.length;
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

  const queue: string[][] = [[beginWord]];
  const visited = new Set<string>();
  visited.add(beginWord);

  while (queue.length > 0) {
    const path = queue.shift()!;
    const currentWord = path[path.length - 1];

    if (currentWord === endWord) {
      return path;
    }

    // Try all 1-letter variations
    for (let i = 0; i < wordLen; i++) {
      for (let c = 0; c < 26; c++) {
        const char = alphabet[c];
        if (char === currentWord[i]) continue;

        const nextWord = currentWord.substring(0, i) + char + currentWord.substring(i + 1);

        if (dict.has(nextWord) && !visited.has(nextWord)) {
          visited.add(nextWord);
          queue.push([...path, nextWord]);
        }
      }
    }
  }

  return null;
}
