export interface WordScrambleItem {
  original: string;
  scrambled: string;
  clue?: string;
  letterCount: number;
}

export interface WordScrambleResult {
  items: WordScrambleItem[];
}

export function generateWordScramble(
  inputList: { word: string; clue?: string }[]
): WordScrambleResult {
  const items: WordScrambleItem[] = [];

  for (const item of inputList) {
    const rawWord = item.word.trim();
    if (!rawWord) continue;

    const original = rawWord.toUpperCase();
    const scrambled = scrambleLetters(original);

    items.push({
      original,
      scrambled,
      clue: item.clue?.trim() || undefined,
      letterCount: original.replace(/[^A-Z]/g, '').length,
    });
  }

  return { items };
}

function scrambleLetters(word: string): string {
  // If word has spaces (e.g. compound words), scramble each token
  const tokens = word.split(' ');
  const scrambledTokens = tokens.map(token => {
    const chars = token.split('');
    if (chars.length <= 1) return token;

    // Check if all characters are identical (e.g. "ZZZ")
    const isAllSame = chars.every(c => c === chars[0]);
    if (isAllSame) return token;

    let scrambled = chars.slice();
    let attempts = 0;

    // Shuffle until different from original
    while (attempts < 50) {
      for (let i = scrambled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [scrambled[i], scrambled[j]] = [scrambled[j], scrambled[i]];
      }
      if (scrambled.join('') !== token) break;
      attempts++;
    }

    return scrambled.join('');
  });

  return scrambledTokens.join(' ');
}
