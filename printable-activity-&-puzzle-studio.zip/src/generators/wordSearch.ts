export interface WordSearchOptions {
  words: string[];
  width: number;
  height: number;
  allowHorizontal: boolean;
  allowVertical: boolean;
  allowDiagonal: boolean;
  allowReverse: boolean;
}

export interface PlacedWord {
  word: string;
  row: number;
  col: number;
  dRow: number;
  dCol: number;
  path: [number, number][];
}

export interface WordSearchResult {
  grid: string[][];
  solutionGrid: (string | null)[][];
  placedWords: PlacedWord[];
  unplacedWords: string[];
  width: number;
  height: number;
}

export function generateWordSearch(options: WordSearchOptions): WordSearchResult {
  const { width, height } = options;
  const grid: string[][] = Array.from({ length: height }, () => Array(width).fill(''));
  const solutionGrid: (string | null)[][] = Array.from({ length: height }, () => Array(width).fill(null));

  // Determine allowed directional vectors
  const directions: [number, number][] = [];
  if (options.allowHorizontal) {
    directions.push([0, 1]);
    if (options.allowReverse) directions.push([0, -1]);
  }
  if (options.allowVertical) {
    directions.push([1, 0]);
    if (options.allowReverse) directions.push([-1, 0]);
  }
  if (options.allowDiagonal) {
    directions.push([1, 1]);
    directions.push([1, -1]);
    if (options.allowReverse) {
      directions.push([-1, 1]);
      directions.push([-1, -1]);
    }
  }

  // Fallback direction if none selected
  if (directions.length === 0) {
    directions.push([0, 1]);
  }

  // Filter & clean words (uppercase, letters only)
  const cleanWords = Array.from(
    new Set(
      options.words
        .map(w => w.trim().toUpperCase().replace(/[^A-Z]/g, ''))
        .filter(w => w.length >= 2 && w.length <= Math.max(width, height))
    )
  );

  // Sort longest first
  cleanWords.sort((a, b) => b.length - a.length);

  const placedWords: PlacedWord[] = [];
  const unplacedWords: string[] = [];

  for (const word of cleanWords) {
    let placed = false;
    // Attempt multiple random positions & directions
    const attempts = 300;

    for (let attempt = 0; attempt < attempts; attempt++) {
      const [dRow, dCol] = directions[Math.floor(Math.random() * directions.length)];
      
      // Calculate valid starting bounds
      const minRow = dRow < 0 ? word.length - 1 : 0;
      const maxRow = dRow > 0 ? height - word.length : height - 1;
      const minCol = dCol < 0 ? word.length - 1 : 0;
      const maxCol = dCol > 0 ? width - word.length : width - 1;

      if (maxRow < minRow || maxCol < minCol) continue;

      const startRow = Math.floor(Math.random() * (maxRow - minRow + 1)) + minRow;
      const startCol = Math.floor(Math.random() * (maxCol - minCol + 1)) + minCol;

      // Check if word fits without collisions
      let fits = true;
      const path: [number, number][] = [];

      for (let i = 0; i < word.length; i++) {
        const r = startRow + i * dRow;
        const c = startCol + i * dCol;
        const char = word[i];
        if (grid[r][c] !== '' && grid[r][c] !== char) {
          fits = false;
          break;
        }
        path.push([r, c]);
      }

      if (fits) {
        // Place word in grid and record in solution
        for (let i = 0; i < word.length; i++) {
          const [r, c] = path[i];
          grid[r][c] = word[i];
          solutionGrid[r][c] = word[i];
        }

        placedWords.push({
          word,
          row: startRow,
          col: startCol,
          dRow,
          dCol,
          path,
        });

        placed = true;
        break;
      }
    }

    if (!placed) {
      unplacedWords.push(word);
    }
  }

  // Fill empty spots with random letters (A-Z)
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  for (let r = 0; r < height; r++) {
    for (let c = 0; c < width; c++) {
      if (grid[r][c] === '') {
        grid[r][c] = alphabet[Math.floor(Math.random() * alphabet.length)];
      }
    }
  }

  // Sort placed words alphabetically for the student word bank
  placedWords.sort((a, b) => a.word.localeCompare(b.word));

  return {
    grid,
    solutionGrid,
    placedWords,
    unplacedWords,
    width,
    height,
  };
}
