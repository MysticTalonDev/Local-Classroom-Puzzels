export type GeneratorType =
  | 'word-search'
  | 'crossword'
  | 'bingo'
  | 'word-scramble'
  | 'cryptogram'
  | 'maze'
  | 'matching'
  | 'sudoku'
  | 'word-ladder'
  | 'fill-blank';

export interface HeaderSettings {
  title: string;
  subtitle: string;
  showNameLine: boolean;
  showDateLine: boolean;
  showScoreLine: boolean;
  showTeacherLine: boolean;
  fontSize: 'sm' | 'base' | 'lg';
  borderColor: string; // hex or css color
  fontFamily: 'sans' | 'serif' | 'mono' | 'comic';
}

export interface PresetItem {
  name: string;
  description: string;
  data: any;
}
