import jsPDF from 'jspdf';
import { toJpeg } from 'html-to-image';

export interface PdfGenerationResult {
  doc: jsPDF;
  blobUrl: string;
  blob: Blob;
  filename: string;
}

/**
 * Captures all .worksheet-paper elements on the page and generates a clean,
 * high-resolution multi-page PDF formatted for standard A4 / Letter portrait paper.
 * Uses html-to-image (SVG foreignObject) so modern CSS color functions like oklch()
 * in Tailwind CSS v4 are rendered natively by the browser without parsing errors.
 */
export async function generatePdfFromWorksheet(
  title: string = 'Worksheet',
  onProgress?: (progressText: string) => void
): Promise<PdfGenerationResult> {
  const papers = Array.from(document.querySelectorAll<HTMLElement>('.worksheet-paper'));

  if (papers.length === 0) {
    throw new Error('No printable worksheet found on the current page.');
  }

  onProgress?.('Preparing worksheet pages...');

  // Standard A4 dimensions in mm (210 x 297)
  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = 210;
  const pageHeight = 297;

  for (let i = 0; i < papers.length; i++) {
    const paper = papers[i];
    onProgress?.(`Rendering page ${i + 1} of ${papers.length}...`);

    if (i > 0) {
      pdf.addPage('a4', 'portrait');
    }

    // Capture using html-to-image with 2x pixel ratio for crisp vector & text rendering
    const imgData = await toJpeg(paper, {
      quality: 0.95,
      pixelRatio: 2,
      backgroundColor: '#ffffff',
      cacheBust: false,
    });

    const imgProps = pdf.getImageProperties(imgData);

    const pdfImgWidth = pageWidth;
    const pdfImgHeight = (imgProps.height * pdfImgWidth) / imgProps.width;

    // Center vertically if height is less than full page, otherwise align top
    const yOffset = pdfImgHeight < pageHeight ? Math.max(0, (pageHeight - pdfImgHeight) / 4) : 0;

    pdf.addImage(
      imgData,
      'JPEG',
      0,
      yOffset,
      pdfImgWidth,
      Math.min(pageHeight, pdfImgHeight)
    );
  }

  onProgress?.('Finalizing PDF document...');

  const sanitizedTitle = (title || 'worksheet')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
  const filename = `${sanitizedTitle || 'printable-activity'}.pdf`;

  const blob = pdf.output('blob');
  const blobUrl = URL.createObjectURL(blob);

  return { doc: pdf, blobUrl, blob, filename };
}
